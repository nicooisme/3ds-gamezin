#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 - <<'PY_BUILD'
from pathlib import Path
import os
for d in ["acc","chars","cloth","foe","hair","hp","logo","tiles"]:
    folder=Path('gfx')/d
    if folder.is_dir():
        pngs=sorted([p.name for p in folder.iterdir() if p.suffix.lower()=='.png'])
        (Path('gfx')/f'{d}.t3s').write_text('--atlas\n--format rgba5551\n\n'+'\n'.join(f'{d}/{x}' for x in pngs)+'\n')
PY_BUILD
docker run --rm -v "$PWD":/project -w /project devkitpro/devkitarm:latest make clean
docker run --rm -v "$PWD":/project -w /project devkitpro/devkitarm:latest make -j1 V=1
# Para CIA, se 3dstool/makerom/bannertool estiverem disponiveis:
# docker run --rm -v "$PWD":/project -w /project devkitpro/devkitarm:latest make cia
