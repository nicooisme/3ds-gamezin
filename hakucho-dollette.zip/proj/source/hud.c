#include "game.h"
#include <stdio.h>
#include <math.h>

/* team ink colors */
#define ORANGE_R 255
#define ORANGE_G 122
#define ORANGE_B 24
#define BLUE_R   43
#define BLUE_G   140
#define BLUE_B   255
#define INK_A    140

/* fundo rosa com bolinhas (polka dots) — usado no menu/HUD */
void draw_polkadot_bg(float w, float h)
{
    C2D_DrawRectSolid(0, 0, 0.0f, w, h, C2D_Color32(255, 150, 190, 255));
    const float step = 34.0f;
    u32 dot = C2D_Color32(255, 205, 222, 255);
    int row = 0;
    for (float y = 10; y < h + step; y += step, row++) {
        float ox = (row & 1) ? step * 0.5f : 0.0f;
        for (float x = 10 + ox; x < w + step; x += step)
            C2D_DrawCircleSolid(x, y, 0.0f, 7.0f, dot);
    }
}

/* ---- camera follows player, clamped to map ---- */
static void camera_for(Game *g, float *camX, float *camY)
{
    float px = g->ent[0].x, py = g->ent[0].y;
    float viewW = TOP_W / ZOOM;
    float viewH = TOP_H / ZOOM;
    float cx = px - viewW * 0.5f;
    float cy = py - viewH * 0.5f;
    float maxX = MAP_W * TILE - viewW;
    float maxY = MAP_H * TILE - viewH;
    if (cx < 0) cx = 0;
    if (cx > maxX) cx = maxX;
    if (cy < 0) cy = 0;
    if (cy > maxY) cy = maxY;
    *camX = cx; *camY = cy;
}

void draw_top(Game *g, Assets *a, C3D_RenderTarget *top)
{
    C2D_SceneBegin(top);
    C2D_TargetClear(top, C2D_Color32(10, 20, 40, 255));

    float camX, camY;
    camera_for(g, &camX, &camY);

    /* visible tile range */
    int tx0 = (int)(camX / TILE);
    int ty0 = (int)(camY / TILE);
    int tx1 = tx0 + (int)(TOP_W / (TILE * ZOOM)) + 2;
    int ty1 = ty0 + (int)(TOP_H / (TILE * ZOOM)) + 2;
    if (tx0 < 0) tx0 = 0;
    if (ty0 < 0) ty0 = 0;
    if (tx1 > MAP_W) tx1 = MAP_W;
    if (ty1 > MAP_H) ty1 = MAP_H;

    /* terrain (scaled by ZOOM) */
    for (int ty = ty0; ty < ty1; ty++) {
        for (int tx = tx0; tx < tx1; tx++) {
            int kind = g->tiles[ty][tx];
            float sx = (tx * TILE - camX) * ZOOM;
            float sy = (ty * TILE - camY) * ZOOM;
            C2D_DrawImageAt(a->tile[kind], sx, sy, 0.0f, NULL, ZOOM, ZOOM);
        }
    }

    /* suaviza a costa: nas quinas terra/agua desenha um arco de agua,
       quebrando o serrilhado de 16px (deixa a ilha menos quadrada) */
    {
        u32 water = C2D_Color32(2, 179, 237, 255);   /* cor media da agua */
        float r = TILE * 0.5f * ZOOM;
        for (int ty = ty0; ty < ty1; ty++) {
            for (int tx = tx0; tx < tx1; tx++) {
                if (g->tiles[ty][tx] == T_WATER) continue;
                bool wl = (tx > 0)        && g->tiles[ty][tx-1] == T_WATER;
                bool wr = (tx < MAP_W-1)  && g->tiles[ty][tx+1] == T_WATER;
                bool wu = (ty > 0)        && g->tiles[ty-1][tx] == T_WATER;
                bool wd = (ty < MAP_H-1)  && g->tiles[ty+1][tx] == T_WATER;
                float bx = (tx * TILE - camX) * ZOOM;
                float by = (ty * TILE - camY) * ZOOM;
                float cw = TILE * ZOOM;
                /* canto diagonal cercado por agua em dois lados -> arredonda */
                if (wl && wu) C2D_DrawCircleSolid(bx,      by,      0.05f, r, water);
                if (wr && wu) C2D_DrawCircleSolid(bx + cw, by,      0.05f, r, water);
                if (wl && wd) C2D_DrawCircleSolid(bx,      by + cw, 0.05f, r, water);
                if (wr && wd) C2D_DrawCircleSolid(bx + cw, by + cw, 0.05f, r, water);
            }
        }
    }

    /* ink layer (semitransparent) */
    int px0 = (int)(camX / PAINT), py0 = (int)(camY / PAINT);
    int px1 = px0 + (int)(TOP_W / (PAINT * ZOOM)) + 2;
    int py1 = py0 + (int)(TOP_H / (PAINT * ZOOM)) + 2;
    if (px0 < 0) px0 = 0;
    if (py0 < 0) py0 = 0;
    if (px1 > PAINT_W) px1 = PAINT_W;
    if (py1 > PAINT_H) py1 = PAINT_H;
    for (int y = py0; y < py1; y++) {
        for (int x = px0; x < px1; x++) {
            int owner = g->paint[y][x];
            if (owner == P_NONE) continue;
            u32 col = (owner == P_ORANGE)
                ? C2D_Color32(ORANGE_R, ORANGE_G, ORANGE_B, INK_A)
                : C2D_Color32(BLUE_R, BLUE_G, BLUE_B, INK_A);
            /* gota circular centrada na celula, raio > meia-celula para
               cobrir as juntas e dar contorno organico (menos quadrado) */
            float cxp = (x * PAINT + PAINT * 0.5f - camX) * ZOOM;
            float cyp = (y * PAINT + PAINT * 0.5f - camY) * ZOOM;
            C2D_DrawCircleSolid(cxp, cyp, 0.0f, PAINT * 0.95f * ZOOM, col);
        }
    }

    /* entities: team ring at base + personagem composto (corpo+roupa+cabelo) */
    for (int i = 0; i < MAX_ENT; i++) {
        Entity *e = &g->ent[i];
        if (!e->alive) continue;
        if (e->invuln > 0.0f && ((int)(e->invuln * 12) & 1)) continue; /* blink */

        float sx = (e->x - camX) * ZOOM;
        float sy = (e->y - camY) * ZOOM;

        u32 ring = (e->team == TEAM_ORANGE)
            ? C2D_Color32(ORANGE_R, ORANGE_G, ORANGE_B, 220)
            : C2D_Color32(BLUE_R, BLUE_G, BLUE_B, 220);
        /* ellipse removida para compatibilidade */

        draw_character(a, e->skin, e->hair, e->cloth, e->acc,
                       e->walking, e->frame, e->facing, sx, sy, 1.0f);
    }

    /* projeteis de tinta (gotas) */
    for (int s = 0; s < MAX_SHOTS; s++) {
        const Shot *sh = &g->shots[s];
        if (!sh->active) continue;
        float px = (sh->x - camX) * ZOOM;
        float py = (sh->y - camY) * ZOOM;
        u32 col = (sh->team == TEAM_ORANGE)
            ? C2D_Color32(ORANGE_R, ORANGE_G, ORANGE_B, 255)
            : C2D_Color32(BLUE_R, BLUE_G, BLUE_B, 255);
        C2D_DrawCircleSolid(px, py, 0.3f, 3.5f * ZOOM, col);
    }

    /* dente alado (inimigo neutro) */
    if (g->tooth.active) {
        float tx = (g->tooth.x - camX) * ZOOM;
        float ty = (g->tooth.y - camY) * ZOOM;
        /* sombrinha sutil sob ele */
        /* ellipse removida para compatibilidade */
        C2D_Sprite *spr = &a->tooth[g->tooth.frame % TOOTH_FRAMES];
        C2D_SpriteSetPos(spr, tx, ty);
        C2D_SpriteSetDepth(spr, 0.2f);
        C2D_SpriteSetScale(spr, ZOOM, ZOOM);   /* acompanha o zoom do mundo */
        C2D_DrawSprite(spr);
    }
}

/* ---- desenha um personagem composto (corpo + roupa + cabelo) ----
   As 3 camadas compartilham o mesmo recorte (28x26) e o mesmo centro
   (0.5, 0.9), entao desenhar todas no mesmo (x,y) e escala mantem o
   alinhamento perfeito. */
static void draw_layer(C2D_Sprite *spr, float x, float y, float scale,
                       int facing, float depth)
{
    C2D_SpriteSetPos(spr, x, y);
    C2D_SpriteSetDepth(spr, depth);
    C2D_SpriteSetScale(spr, (float)facing * scale, scale);
    C2D_DrawSprite(spr);
}

void draw_character(Assets *a, int skin, int hair, int cloth, int acc,
                    bool walking, int frame, int facing,
                    float x, float y, float scale)
{
    int wf = frame % WALK_FRAMES;
    int idf = frame % IDLE_FRAMES;

    C2D_Sprite *body  = walking ? &a->chr[skin].walk[wf]   : &a->chr[skin].idle[idf];
    C2D_Sprite *cl    = walking ? &a->cloth[cloth].walk[wf]: &a->cloth[cloth].idle[idf];
    C2D_Sprite *hr    = walking ? &a->hair[hair].walk[wf]  : &a->hair[hair].idle[idf];

    draw_layer(body, x, y, scale, facing, 0.10f);   /* corpo  */
    draw_layer(cl,   x, y, scale, facing, 0.11f);    /* roupa  */
    draw_layer(hr,   x, y, scale, facing, 0.12f);    /* cabelo */

    /* acessorio: 0 = nenhum; 1..NUM_ACC -> indice 0..NUM_ACC-1, POR CIMA do cabelo */
    if (acc >= 1 && acc <= NUM_ACC) {
        int ai = acc - 1;
        C2D_Sprite *ac = walking ? &a->acc[ai].walk[wf] : &a->acc[ai].idle[idf];
        draw_layer(ac, x, y, scale, facing, 0.13f);
    }
}

static void draw_heart(Assets *a, float x, float y, bool full)
{
    C2D_Image img = full ? a->hpFull : a->hpEmpty;
    /* hearts are 64px source; draw ~52px */
    float s = 52.0f / 64.0f;
    C2D_DrawImageAt(img, x, y, 0.5f, NULL, s, s);
}

void draw_bottom(Game *g, Assets *a, C3D_RenderTarget *bot)
{
    C2D_SceneBegin(bot);
    C2D_TargetClear(bot, C2D_Color32(24, 24, 32, 255));
    draw_polkadot_bg(BOT_W, BOT_H);

    /* 5 hearts */
    int hp = (int)ceilf(g->ent[0].hp);
    for (int i = 0; i < 5; i++)
        draw_heart(a, 8 + i * 56, 10, i < hp);

    /* timer mm:ss centered */
    int total = (int)ceilf(g->timeLeft);
    if (total < 0) total = 0;
    char buf[16];
    snprintf(buf, sizeof buf, "%02d:%02d", total / 60, total % 60);
    C2D_Text txt; C2D_TextBuf tb = C2D_TextBufNew(64);
    C2D_TextParse(&txt, tb, buf);
    C2D_TextOptimize(&txt);
    float tw, th; C2D_TextGetDimensions(&txt, 1.6f, 1.6f, &tw, &th);
    C2D_DrawText(&txt, C2D_WithColor, (BOT_W - tw) / 2, 78,
                 0.5f, 1.6f, 1.6f, C2D_Color32(255, 255, 255, 255));
    C2D_TextBufDelete(tb);

    /* score LARANJA % x AZUL % */
    char sc[48];
    snprintf(sc, sizeof sc, "LARANJA %d%%   x   AZUL %d%%", g->pctOrange, g->pctBlue);
    C2D_Text st; C2D_TextBuf sb = C2D_TextBufNew(64);
    C2D_TextParse(&st, sb, sc);
    C2D_TextOptimize(&st);
    float sw, sh; C2D_TextGetDimensions(&st, 0.6f, 0.6f, &sw, &sh);
    C2D_DrawText(&st, C2D_WithColor, (BOT_W - sw) / 2, 150,
                 0.5f, 0.6f, 0.6f, C2D_Color32(255, 220, 120, 255));
    C2D_TextBufDelete(sb);

    /* control hint */
    const char *hint =
        (g->state == ST_PLAYING) ? "Circle Pad para mover" :
        (g->state == ST_TITLE)   ? "Pressione START" :
                                   "START para jogar de novo";
    C2D_Text ht; C2D_TextBuf hb = C2D_TextBufNew(64);
    C2D_TextParse(&ht, hb, hint);
    C2D_TextOptimize(&ht);
    float hw, hh; C2D_TextGetDimensions(&ht, 0.5f, 0.5f, &hw, &hh);
    C2D_DrawText(&ht, C2D_WithColor, (BOT_W - hw) / 2, 200,
                 0.5f, 0.5f, 0.5f, C2D_Color32(180, 180, 190, 255));
    C2D_TextBufDelete(hb);
}
