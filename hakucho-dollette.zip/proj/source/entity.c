#include "game.h"
#include <math.h>
#include <stdlib.h>

static float frand(void) { return (rand() % 10000) / 10000.0f; }

void entity_spawn(Game *g, int i)
{
    Entity *e = &g->ent[i];
    int t = e->team;
    e->x = g->baseX[t] + (frand() - 0.5f) * TILE;
    e->y = g->baseY[t] + (frand() - 0.5f) * TILE;
    /* nudge to land if needed */
    if (!map_is_land_px(g, e->x, e->y)) { e->x = g->baseX[t]; e->y = g->baseY[t]; }
    e->hp = ENT_MAX_HP;
    e->alive = true;
    e->deadTimer = 0.0f;
    e->invuln = INVULN_TIME;
    e->walking = false;
    e->animTime = 0.0f;
    e->frame = 0;
    e->facing = 1;
    e->aimX = 0.0f; e->aimY = (e->team == TEAM_ORANGE) ? -1.0f : 1.0f; /* mira pro campo inimigo */
    e->shootCd = 0.0f;
    e->meleeCd = 0.0f;
    e->aiTimer = 0.5f + frand() * 1.5f;
    e->tx = e->x; e->ty = e->y;
}

void entity_init_all(Game *g)
{
    /* Jogador (0): time BRANCO (TEAM_ORANGE), com a skin montada.
       Inimigos (1..3): time VERMELHO (TEAM_BLUE), skin propria, sem roupa. */
    int teams[MAX_ENT] = { TEAM_ORANGE, TEAM_BLUE, TEAM_BLUE, TEAM_BLUE };

    for (int i = 0; i < MAX_ENT; i++) {
        g->ent[i].team  = teams[i];
        if (i == 0) {
            /* jogador usa o que escolheu na personalizacao */
            g->ent[i].skin  = g->selSkin;
            g->ent[i].hair  = g->selHair;
            g->ent[i].cloth = g->selCloth;
            g->ent[i].acc   = g->selAcc;
        } else {
            /* inimigo vermelho: boneco proprio, sem roupa/cabelo/acessorio */
            g->ent[i].skin  = ENEMY_SKIN;
            g->ent[i].hair  = -1;   /* sem cabelo */
            g->ent[i].cloth = -1;   /* sem roupa  */
            g->ent[i].acc   = 0;    /* sem acessorio */
        }
    }

    for (int i = 0; i < MAX_ENT; i++)
        entity_spawn(g, i);
}

void entity_damage(Game *g, int i, float amount)
{
    Entity *e = &g->ent[i];
    if (!e->alive || e->invuln > 0.0f) return;
    e->hp -= amount;
    if (e->hp <= 0.0f) {
        e->hp = 0.0f;
        e->alive = false;
        e->deadTimer = DEAD_TIME;
    }
}

/* try to move with collision against water; returns true if moved */
static bool try_move(Game *g, Entity *e, float nx, float ny)
{
    if (map_is_land_px(g, nx, e->y)) e->x = nx;
    if (map_is_land_px(g, e->x, ny)) e->y = ny;
    /* clamp to top-screen world bounds */
    if (e->x < 4) e->x = 4;
    if (e->x > MAP_W * TILE - 4) e->x = MAP_W * TILE - 4;
    if (e->y < 4) e->y = 4;
    if (e->y > MAP_H * TILE - 4) e->y = MAP_H * TILE - 4;
    return true;
}

static void move_dir(Game *g, Entity *e, float dx, float dy, float dt)
{
    float len = sqrtf(dx * dx + dy * dy);
    if (len < 0.001f) { e->walking = false; return; }
    dx /= len; dy /= len;

    float speed = ENT_SPEED;
    int onPaint = map_paint_owner_px(g, e->x, e->y);
    int enemyPaint = (e->team == TEAM_ORANGE) ? P_BLUE : P_ORANGE;
    if (onPaint == enemyPaint) speed *= 0.5f;   /* slow on enemy ink */

    float nx = e->x + dx * speed * dt;
    float ny = e->y + dy * speed * dt;
    try_move(g, e, nx, ny);

    if (dx < -0.1f) e->facing = -1; else if (dx > 0.1f) e->facing = 1;
    e->aimX = dx; e->aimY = dy;   /* lembra a direcao apontada para o tiro */
    e->walking = true;

    /* paint own-color trail under the feet */
    int own = (e->team == TEAM_ORANGE) ? P_ORANGE : P_BLUE;
    map_paint_at(g, e->x, e->y, own, PAINT_RADIUS);
}

static void ai_update(Game *g, Entity *e, float dt)
{
    /* find nearest enemy within ~140px */
    float best = 140.0f * 140.0f; int target = -1;
    for (int j = 0; j < MAX_ENT; j++) {
        Entity *o = &g->ent[j];
        if (!o->alive || o->team == e->team) continue;
        float dx = o->x - e->x, dy = o->y - e->y;
        float d2 = dx * dx + dy * dy;
        if (d2 < best) { best = d2; target = j; }
    }

    if (target >= 0) {
        Entity *o = &g->ent[target];
        float dx = o->x - e->x, dy = o->y - e->y;
        float d = sqrtf(dx * dx + dy * dy) + 0.001f;
        e->aimX = dx / d; e->aimY = dy / d;   /* mira no alvo */
        if (d < 70.0f) {
            move_dir(g, e, -dx, -dy, dt);  /* keep distance: back off */
        } else {
            move_dir(g, e, dx, dy, dt);    /* chase */
        }
        /* atira se estiver em alcance util */
        if (d < 130.0f) entity_shoot(g, e - g->ent);
        return;
    }

    /* wander */
    e->aiTimer -= dt;
    float dx = e->tx - e->x, dy = e->ty - e->y;
    if (e->aiTimer <= 0.0f || (dx * dx + dy * dy) < 36.0f) {
        e->aiTimer = 1.2f + frand() * 1.6f;     /* 1.2 .. 2.8s */
        /* pick a random land point */
        for (int tries = 0; tries < 16; tries++) {
            float rx = frand() * (MAP_W * TILE);
            float ry = frand() * (MAP_H * TILE);
            if (map_is_land_px(g, rx, ry)) { e->tx = rx; e->ty = ry; break; }
        }
        dx = e->tx - e->x; dy = e->ty - e->y;
    }
    move_dir(g, e, dx, dy, dt);
}

void entity_shoot(Game *g, int i)
{
    Entity *e = &g->ent[i];
    if (!e->alive || e->shootCd > 0.0f) return;

    float ax = e->aimX, ay = e->aimY;
    float len = sqrtf(ax * ax + ay * ay);
    if (len < 0.01f) { ax = (float)e->facing; ay = 0.0f; len = 1.0f; }
    ax /= len; ay /= len;

    for (int s = 0; s < MAX_SHOTS; s++) {
        if (g->shots[s].active) continue;
        Shot *sh = &g->shots[s];
        sh->active = true;
        sh->x = e->x + ax * 6.0f;
        sh->y = e->y - 8.0f + ay * 6.0f;   /* sai na altura do tronco */
        sh->vx = ax * SHOT_SPEED;
        sh->vy = ay * SHOT_SPEED;
        sh->life = SHOT_LIFE;
        sh->team = e->team;
        break;
    }
    e->shootCd = SHOOT_CD;
}

void entity_melee(Game *g, int i)
{
    Entity *e = &g->ent[i];
    if (!e->alive || e->meleeCd > 0.0f) return;
    e->meleeCd = MELEE_CD;

    for (int j = 0; j < MAX_ENT; j++) {
        Entity *o = &g->ent[j];
        if (j == i || !o->alive || o->team == e->team) continue;
        float dx = o->x - e->x, dy = o->y - e->y;
        if (dx * dx + dy * dy <= MELEE_RANGE * MELEE_RANGE)
            entity_damage(g, j, MELEE_DMG);
    }
}

void shots_update(Game *g, float dt)
{
    for (int s = 0; s < MAX_SHOTS; s++) {
        Shot *sh = &g->shots[s];
        if (!sh->active) continue;

        sh->x += sh->vx * dt;
        sh->y += sh->vy * dt;
        sh->life -= dt;

        int owner = (sh->team == TEAM_ORANGE) ? P_ORANGE : P_BLUE;

        /* pinta o caminho */
        if (map_is_land_px(g, sh->x, sh->y))
            map_paint_at(g, sh->x, sh->y, owner, SHOT_RADIUS);

        /* acerto em inimigo? */
        for (int j = 0; j < MAX_ENT; j++) {
            Entity *o = &g->ent[j];
            if (!o->alive || o->team == sh->team) continue;
            float dx = o->x - sh->x, dy = (o->y - 8.0f) - sh->y;
            if (dx * dx + dy * dy <= 100.0f) {   /* raio ~10px */
                entity_damage(g, j, SHOT_DMG);
                /* respingo maior no impacto */
                map_paint_at(g, sh->x, sh->y, owner, SHOT_RADIUS + 4.0f);
                sh->active = false;
                break;
            }
        }
        if (!sh->active) continue;

        /* fim de vida, fora do mapa ou caiu na agua: respingo final */
        bool offmap = (sh->x < 0 || sh->y < 0 ||
                       sh->x >= MAP_W * TILE || sh->y >= MAP_H * TILE);
        if (sh->life <= 0.0f || offmap || !map_is_land_px(g, sh->x, sh->y)) {
            if (map_is_land_px(g, sh->x, sh->y))
                map_paint_at(g, sh->x, sh->y, owner, SHOT_RADIUS + 3.0f);
            sh->active = false;
        }
    }
}

void entity_update(Game *g, int i, float dt, u32 kHeld, circlePosition cp)
{
    Entity *e = &g->ent[i];

    if (!e->alive) {
        e->deadTimer -= dt;
        if (e->deadTimer <= 0.0f) entity_spawn(g, i);
        return;
    }

    if (e->invuln > 0.0f) e->invuln -= dt;
    if (e->shootCd > 0.0f) e->shootCd -= dt;
    if (e->meleeCd > 0.0f) e->meleeCd -= dt;

    e->walking = false;

    if (i == 0) {
        /* mira pelo D-Pad; movimento pelo circle pad (+ d-pad se nao estiver atirando) */
        bool firing = (kHeld & (KEY_L | KEY_R)) != 0;

        /* vetor do D-Pad */
        float dpx = 0, dpy = 0;
        if (kHeld & KEY_LEFT)  dpx -= 1.0f;
        if (kHeld & KEY_RIGHT) dpx += 1.0f;
        if (kHeld & KEY_UP)    dpy -= 1.0f;
        if (kHeld & KEY_DOWN)  dpy += 1.0f;

        /* enquanto atira, o D-Pad MIRA (nao move) */
        if (firing && (dpx != 0 || dpy != 0)) {
            float len = sqrtf(dpx * dpx + dpy * dpy);
            e->aimX = dpx / len; e->aimY = dpy / len;
            if (dpx < -0.1f) e->facing = -1; else if (dpx > 0.1f) e->facing = 1;
        }

        /* movimento: circle pad sempre; d-pad tambem quando NAO esta atirando */
        float dx = 0, dy = 0;
        const int DEAD = (int)(0.18f * 156);
        if (abs(cp.dx) > DEAD) dx += cp.dx / 156.0f;
        if (abs(cp.dy) > DEAD) dy += -cp.dy / 156.0f;  /* inverte Y */
        if (!firing) { dx += dpx; dy += dpy; }
        if (dx != 0 || dy != 0) move_dir(g, e, dx, dy, dt);

        if (firing)        entity_shoot(g, i);   /* L/R dispara */
        if (kHeld & KEY_A) entity_melee(g, i);   /* A ataca corpo-a-corpo */
    } else {
        ai_update(g, e, dt);
    }

    /* floor effects: heal on own ink, damage on enemy ink */
    int onPaint = map_paint_owner_px(g, e->x, e->y);
    int own   = (e->team == TEAM_ORANGE) ? P_ORANGE : P_BLUE;
    int enemy = (e->team == TEAM_ORANGE) ? P_BLUE : P_ORANGE;
    if (onPaint == own && e->hp < ENT_MAX_HP) {
        e->hp += 0.4f * dt;
        if (e->hp > ENT_MAX_HP) e->hp = ENT_MAX_HP;
    } else if (onPaint == enemy) {
        if (e->invuln <= 0.0f) {
            e->hp -= 0.5f * dt;
            if (e->hp <= 0.0f) { e->hp = 0; e->alive = false; e->deadTimer = DEAD_TIME; }
        }
    }

    /* animation */
    e->animTime += dt;
    if (e->walking) {
        if (e->animTime > 0.08f) { e->animTime = 0; e->frame = (e->frame + 1) % WALK_FRAMES; }
    } else {
        if (e->animTime > 0.40f) { e->animTime = 0; e->frame = (e->frame + 1) % IDLE_FRAMES; }
    }
}

/* ===== Dente alado (inimigo neutro que surge do nada) ===== */
static void tooth_spawn(Game *g)
{
    /* nasce numa borda aleatoria do mundo */
    int side = rand() % 4;
    float W = MAP_W * TILE, H = MAP_H * TILE;
    switch (side) {
        case 0: g->tooth.x = 0;     g->tooth.y = frand() * H; break;
        case 1: g->tooth.x = W;     g->tooth.y = frand() * H; break;
        case 2: g->tooth.x = frand() * W; g->tooth.y = 0;     break;
        default:g->tooth.x = frand() * W; g->tooth.y = H;     break;
    }
    g->tooth.active = true;
    g->tooth.life = TOOTH_LIFE;
    g->tooth.animTime = 0;
    g->tooth.frame = 0;
    g->tooth.vx = g->tooth.vy = 0;
}

void tooth_update(Game *g, float dt)
{
    if (!g->tooth.active) {
        g->toothSpawnTimer -= dt;
        if (g->toothSpawnTimer <= 0.0f) {
            tooth_spawn(g);
            g->toothSpawnTimer = TOOTH_SPAWN_MIN +
                frand() * (TOOTH_SPAWN_MAX - TOOTH_SPAWN_MIN);
        }
        return;
    }

    /* persegue o jogador vivo mais proximo */
    float bx = g->tooth.x, by = g->tooth.y, best = 1e9f; int found = 0;
    for (int j = 0; j < MAX_ENT; j++) {
        if (!g->ent[j].alive) continue;
        float dx = g->ent[j].x - g->tooth.x, dy = g->ent[j].y - g->tooth.y;
        float d2 = dx * dx + dy * dy;
        if (d2 < best) { best = d2; bx = g->ent[j].x; by = g->ent[j].y; found = 1; }
    }
    if (found) {
        float dx = bx - g->tooth.x, dy = by - g->tooth.y;
        float d = sqrtf(dx * dx + dy * dy) + 0.001f;
        g->tooth.vx = dx / d * TOOTH_SPEED;
        g->tooth.vy = dy / d * TOOTH_SPEED;
    }
    g->tooth.x += g->tooth.vx * dt;
    g->tooth.y += g->tooth.vy * dt;

    /* dano por toque a QUALQUER jogador (inimigo neutro, sem time) */
    for (int j = 0; j < MAX_ENT; j++) {
        Entity *e = &g->ent[j];
        if (!e->alive || e->invuln > 0.0f) continue;
        float dx = e->x - g->tooth.x, dy = e->y - g->tooth.y;
        if (dx * dx + dy * dy <= TOOTH_TOUCH * TOOTH_TOUCH) {
            e->hp -= TOOTH_DMG * dt;   /* dano contInuo enquanto encostado */
            if (e->hp <= 0.0f) { e->hp = 0; e->alive = false; e->deadTimer = DEAD_TIME; }
        }
    }

    /* animacao das asas */
    g->tooth.animTime += dt;
    if (g->tooth.animTime > 0.12f) {
        g->tooth.animTime = 0;
        g->tooth.frame = (g->tooth.frame + 1) % TOOTH_FRAMES;
    }

    g->tooth.life -= dt;
    if (g->tooth.life <= 0.0f) g->tooth.active = false;
}
