#include "game.h"
#include <3ds.h>
#include <string.h>
#include <stdlib.h>

/* compila a implementacao do stb_vorbis aqui dentro */
#include "stb_vorbis.h"

/* ---- streaming de OGG em loop para o canal 0 do ndsp ---- */

#define BGM_CHANNEL   0
#define BGM_WAVEBUFS  3
#define BGM_SAMPLES   16384   /* frames por bloco (por canal) */

static stb_vorbis     *s_vorb       = NULL;
static int             s_chn        = 2;
static int             s_rate       = 44100;
static ndspWaveBuf     s_wavebuf[BGM_WAVEBUFS];
static int16_t        *s_buf[BGM_WAVEBUFS] = { NULL };
static Thread          s_thread     = NULL;
static volatile bool   s_running    = false;
static LightEvent      s_event;

/* preenche um wavebuf com o proximo trecho do ogg; faz loop ao terminar */
static bool fill_wavebuf(ndspWaveBuf *wb, int16_t *buf)
{
    int got = stb_vorbis_get_samples_short_interleaved(
                  s_vorb, s_chn, buf, BGM_SAMPLES * s_chn);
    if (got <= 0) {
        stb_vorbis_seek_start(s_vorb);   /* loop continuo */
        got = stb_vorbis_get_samples_short_interleaved(
                  s_vorb, s_chn, buf, BGM_SAMPLES * s_chn);
        if (got <= 0) return false;
    }
    wb->nsamples = got;
    DSP_FlushDataCache(buf, BGM_SAMPLES * s_chn * sizeof(int16_t));
    ndspChnWaveBufAdd(BGM_CHANNEL, wb);
    return true;
}

static void bgm_thread(void *arg)
{
    (void)arg;
    while (s_running) {
        for (int i = 0; i < BGM_WAVEBUFS; i++) {
            if (s_wavebuf[i].status == NDSP_WBUF_DONE) {
                if (!fill_wavebuf(&s_wavebuf[i], s_buf[i])) { s_running = false; break; }
            }
        }
        LightEvent_Wait(&s_event);
    }
}

static void ndsp_callback(void *arg)
{
    (void)arg;
    if (s_running) LightEvent_Signal(&s_event);
}

void bgm_start(const char *path)
{
    if (s_vorb) return;

    int err = 0;
    s_vorb = stb_vorbis_open_filename(path, &err, NULL);
    if (!s_vorb) return;

    stb_vorbis_info info = stb_vorbis_get_info(s_vorb);
    s_chn  = info.channels;
    s_rate = info.sample_rate;
    if (s_chn < 1) s_chn = 2;

    if (ndspInit() != 0) {   /* dsp indisponivel: segue em silencio */
        stb_vorbis_close(s_vorb); s_vorb = NULL;
        return;
    }

    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    ndspChnReset(BGM_CHANNEL);
    ndspChnSetInterp(BGM_CHANNEL, NDSP_INTERP_POLYPHASE);
    ndspChnSetRate(BGM_CHANNEL, (float)s_rate);
    ndspChnSetFormat(BGM_CHANNEL,
        s_chn == 2 ? NDSP_FORMAT_STEREO_PCM16 : NDSP_FORMAT_MONO_PCM16);

    float mix[12]; memset(mix, 0, sizeof mix);
    mix[0] = mix[1] = 1.0f;
    ndspChnSetMix(BGM_CHANNEL, mix);

    LightEvent_Init(&s_event, RESET_ONESHOT);
    ndspSetCallback(ndsp_callback, NULL);

    memset(s_wavebuf, 0, sizeof s_wavebuf);
    for (int i = 0; i < BGM_WAVEBUFS; i++) {
        s_buf[i] = (int16_t *)linearAlloc(BGM_SAMPLES * s_chn * sizeof(int16_t));
        s_wavebuf[i].data_pcm16 = s_buf[i];   /* campo correto p/ PCM16 */
        s_wavebuf[i].status     = NDSP_WBUF_DONE;
    }

    ndspChnSetPaused(BGM_CHANNEL, false);

    s_running = true;
    for (int i = 0; i < BGM_WAVEBUFS; i++)
        fill_wavebuf(&s_wavebuf[i], s_buf[i]);

    /* thread no core 1 (sistema) com prioridade alta o suficiente para
       acompanhar o consumo do ndsp, melhorando a confiabilidade no hardware. */
    s32 prio = 0x30;
    svcGetThreadPriority(&prio, CUR_THREAD_HANDLE);
    s32 tprio = prio - 1;
    if (tprio < 0x18) tprio = 0x18;
    s_thread = threadCreate(bgm_thread, NULL, 16 * 1024, tprio, 1, false);
    if (!s_thread)  /* fallback: qualquer core */
        s_thread = threadCreate(bgm_thread, NULL, 16 * 1024, tprio, -1, false);
}

void bgm_stop(void)
{
    if (!s_vorb) return;
    s_running = false;
    LightEvent_Signal(&s_event);
    if (s_thread) { threadJoin(s_thread, U64_MAX); threadFree(s_thread); s_thread = NULL; }

    ndspChnWaveBufClear(BGM_CHANNEL);
    ndspSetCallback(NULL, NULL);
    ndspExit();

    for (int i = 0; i < BGM_WAVEBUFS; i++) {
        if (s_buf[i]) { linearFree(s_buf[i]); s_buf[i] = NULL; }
    }
    stb_vorbis_close(s_vorb);
    s_vorb = NULL;
}
