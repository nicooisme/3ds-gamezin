#include "game.h"

/* Audio desativado nesta versao para evitar crash no Old 3DS. */
void bgm_start(const char *path) { (void)path; }
void bgm_stop(void) {}
