#include <3ds.h>
#include <string.h>
#include <stdlib.h>

/* stb_vorbis (public domain). Silencia warnings que quebrariam -Werror/-Wall. */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wall"
#pragma GCC diagnostic ignored "-Wextra"
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wmaybe-uninitialized"
#pragma GCC diagnostic ignored "-Wsign-compare"
#define STB_VORBIS_NO_PUSHDATA_API
#define STB_VORBIS_NO_INTEGER_CONVERSION
#include "stb_vorbis.h"
#pragma GCC diagnostic pop

#include "game.h"

/* ===== streaming BGM via NDSP, em loop ===== */
#define BGM_CHANNEL    0
#define BGM_BUFFERS    3
#define BGM_SAMPLES    (8 * 1024)   /* por buffer, por canal */

static stb_vorbis        *s_vorbis = NULL;
static ndspWaveBuf        s_wbuf[BGM_BUFFERS];
static s16               *s_audio  = NULL;
static int                s_channels = 2;
static int                s_rate     = 44100;
static volatile bool      s_running  = false;
static Thread             s_thread;
static LightLock          s_lock;

/* preenche um waveBuf com o proximo trecho; faz loop ao acabar */
static bool fill_buffer(ndspWaveBuf *wb)
{
    s16 *dst = wb->data_pcm16;
    int want = BGM_SAMPLES;          /* frames (amostras por canal) */
    int got  = 0;

    while (got < want) {
        int n = stb_vorbis_get_samples_short_interleaved(
                    s_vorbis, s_channels, dst + got * s_channels,
                    (want - got) * s_channels);
        if (n <= 0) {
            /* fim da musica -> volta ao inicio (loop) */
            stb_vorbis_seek_start(s_vorbis);
            continue;
        }
        got += n;
    }

    wb->nsamples = got;
    DSP_FlushDataCache(wb->data_pcm16,
                       got * s_channels * sizeof(s16));
    return true;
}

static void bgm_thread(void *arg)
{
    (void)arg;
    while (s_running) {
        for (int i = 0; i < BGM_BUFFERS; i++) {
            if (s_wbuf[i].status == NDSP_WBUF_DONE) {
                LightLock_Lock(&s_lock);
                fill_buffer(&s_wbuf[i]);
                ndspChnWaveBufAdd(BGM_CHANNEL, &s_wbuf[i]);
                LightLock_Unlock(&s_lock);
            }
        }
        svcSleepThread(5 * 1000 * 1000); /* 5ms */
    }
}

void bgm_start(const char *path)
{
    int err = 0;
    s_vorbis = stb_vorbis_open_filename(path, &err, NULL);
    if (!s_vorbis) return;

    stb_vorbis_info info = stb_vorbis_get_info(s_vorbis);
    s_channels = info.channels >= 2 ? 2 : 1;
    s_rate     = info.sample_rate;

    ndspInit();
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    ndspChnReset(BGM_CHANNEL);
    ndspChnSetInterp(BGM_CHANNEL, NDSP_INTERP_LINEAR);
    ndspChnSetRate(BGM_CHANNEL, (float)s_rate);
    ndspChnSetFormat(BGM_CHANNEL,
        s_channels == 2 ? NDSP_FORMAT_STEREO_PCM16 : NDSP_FORMAT_MONO_PCM16);

    float mix[12]; memset(mix, 0, sizeof mix);
    mix[0] = mix[1] = 0.8f;   /* volume L/R */
    ndspChnSetMix(BGM_CHANNEL, mix);

    /* aloca buffers de audio em memoria linear (requisito do DSP) */
    size_t perBuf = BGM_SAMPLES * s_channels;
    s_audio = (s16*)linearAlloc(perBuf * BGM_BUFFERS * sizeof(s16));
    memset(s_wbuf, 0, sizeof s_wbuf);
    for (int i = 0; i < BGM_BUFFERS; i++) {
        s_wbuf[i].data_pcm16 = s_audio + i * perBuf;
        s_wbuf[i].status     = NDSP_WBUF_DONE;
        fill_buffer(&s_wbuf[i]);
        ndspChnWaveBufAdd(BGM_CHANNEL, &s_wbuf[i]);
    }

    LightLock_Init(&s_lock);
    s_running = true;
    /* prioridade um pouco abaixo da main p/ nao engasgar o jogo */
    s32 prio = 0x30;
    svcGetThreadPriority(&prio, CUR_THREAD_HANDLE);
    s_thread = threadCreate(bgm_thread, NULL, 16 * 1024, prio + 1, -1, false);
}

void bgm_stop(void)
{
    if (!s_running) return;
    s_running = false;
    if (s_thread) { threadJoin(s_thread, U64_MAX); threadFree(s_thread); s_thread = NULL; }
    ndspChnWaveBufClear(BGM_CHANNEL);
    ndspExit();
    if (s_vorbis) { stb_vorbis_close(s_vorbis); s_vorbis = NULL; }
    if (s_audio)  { linearFree(s_audio); s_audio = NULL; }
}
