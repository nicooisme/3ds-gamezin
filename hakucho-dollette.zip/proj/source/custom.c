#include "game.h"
#include <stdio.h>

/* cores dos times p/ moldura */
#define ORANGE_R 255
#define ORANGE_G 122
#define ORANGE_B 24

void custom_input(Game *g, u32 kDown)
{
    /* Cada botao cicla (so pra frente) as opcoes da sua categoria:
       A = cabelo, B = pele, Y = roupa, X = acessorio.
       selCat so controla qual linha fica destacada no menu. */
    if (kDown & KEY_A) { g->selCat = 1; g->selHair  = (g->selHair  + 1) % NUM_HAIR; }
    if (kDown & KEY_B) { g->selCat = 0; g->selSkin  = (g->selSkin  + 1) % NUM_SKIN_PLAYER; }
    if (kDown & KEY_Y) { g->selCat = 2; g->selCloth = (g->selCloth + 1) % NUM_CLOTHES; }
    if (kDown & KEY_X) { g->selCat = 3; g->selAcc   = (g->selAcc   + 1) % (NUM_ACC + 1); }

    /* D-pad ajusta a posicao da camada em foco (selCat):
       1=cabelo, 2=roupa, 3=acessorio. SELECT zera a camada em foco. */
    float dx = 0, dy = 0;
    if (kDown & KEY_UP)    dy -= 1.0f;
    if (kDown & KEY_DOWN)  dy += 1.0f;
    if (kDown & KEY_LEFT)  dx -= 1.0f;
    if (kDown & KEY_RIGHT) dx += 1.0f;
    if (dx != 0 || dy != 0) {
        if (g->selCat == 1)      { g->hairOffX  += dx; g->hairOffY  += dy; }
        else if (g->selCat == 2) { g->clothOffX += dx; g->clothOffY += dy; }
        else if (g->selCat == 3) { g->accOffX   += dx; g->accOffY   += dy; }
    }
    if (kDown & KEY_SELECT) {
        if (g->selCat == 1)      { g->hairOffX  = 0; g->hairOffY  = 0; }
        else if (g->selCat == 2) { g->clothOffX = 0; g->clothOffY = 0; }
        else if (g->selCat == 3) { g->accOffX   = 0; g->accOffY   = 0; }
    }
}

static void text(C2D_TextBuf buf, const char *s, float x, float y,
                 float sz, u32 col)
{
    C2D_Text t;
    game_text_parse(&t, buf, s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, 0.5f, sz, sz, col);
}

void draw_custom(Game *g, Assets *a, C3D_RenderTarget *top, C3D_RenderTarget *bot)
{
    /* ---------- TELA DE CIMA: preview centralizado ---------- */
    C2D_SceneBegin(top);
    C2D_TargetClear(top, C2D_Color32(255, 224, 236, 255));
    draw_polkadot_bg(TOP_W, TOP_H);

    /* "plataforma" no centro exato da tela de cima */
    float cx = TOP_W * 0.5f;
    float cy = TOP_H * 0.5f;

    /* moldura/aro do time laranja sob os pes */
    /* ellipse removida para compatibilidade */

    /* preview ampliado (3x), parado em idle, virado p/ direita.
       O centro do sprite e (0.5,0.9): para o personagem ficar
       visualmente centrado, deslocamos a ancora um pouco p/ baixo. */
    float scale = 3.0f;
    float footY = cy;   /* ancora agora no centro do sprite */
    draw_character(a, g->selSkin, g->selHair, g->selCloth, g->selAcc,
                   true, 0, +1, cx, footY, scale,
                   g->hairOffX, g->hairOffY,
                   g->clothOffX, g->clothOffY,
                   g->accOffX, g->accOffY);

    C2D_TextBuf tb = C2D_TextBufNew(64);
    text(tb, "Monte seu personagem", cx - 96, 14, 0.7f,
         C2D_Color32(150, 40, 90, 255));
    C2D_TextBufDelete(tb);

    /* ---------- TELA DE BAIXO: menu ---------- */
    C2D_SceneBegin(bot);
    C2D_TargetClear(bot, C2D_Color32(28, 28, 38, 255));
    draw_polkadot_bg(BOT_W, BOT_H);

    C2D_TextBuf b = C2D_TextBufNew(256);
    const char *names[4] = { "Pele", "Cabelo", "Roupa", "Acessorio" };

    for (int i = 0; i < 4; i++) {
        float y = 30 + i * 36;
        bool focus = (g->selCat == i);
        u32 col = focus ? C2D_Color32(255, 255, 255, 255)
                        : C2D_Color32(150, 60, 100, 255);
        if (focus)
            C2D_DrawRectSolid(14, y - 5, 0.0f, BOT_W - 28, 30,
                              C2D_Color32(228, 90, 150, 235));

        char line[48];
        if (i == 3) {
            /* acessorio: 0 = Nenhum */
            if (g->selAcc == 0)
                snprintf(line, sizeof line, "%s  <  Nenhum  >", names[i]);
            else
                snprintf(line, sizeof line, "%s  <  %d / %d  >",
                         names[i], g->selAcc, NUM_ACC);
        } else {
            int val = (i == 0) ? g->selSkin + 1
                    : (i == 1) ? g->selHair + 1
                               : g->selCloth + 1;
            int mx  = (i == 0) ? NUM_SKIN_PLAYER
                    : (i == 1) ? NUM_HAIR
                               : NUM_CLOTHES;
            snprintf(line, sizeof line, "%s  <  %d / %d  >", names[i], val, mx);
        }
        text(b, line, 28, y, 0.65f, col);
    }

    text(b, "A:cabelo  B:pele  Y:roupa  X:acessorio",
         16, 176, 0.42f, C2D_Color32(150, 60, 100, 235));
    text(b, "D-pad: mover a peca em foco  SELECT: zerar",
         16, 190, 0.42f, C2D_Color32(180, 80, 120, 235));
    text(b, "START: comecar a partida",
         18, 204, 0.48f, C2D_Color32(120, 40, 90, 255));
    C2D_TextBufDelete(b);
}
