# 白鳥の天使 — Hakuchou no Tenshi

A 2-minute Splatoon-style **ink war** for the **Nintendo 3DS** (works on Old 3DS),
written in C with devkitARM + libctru + citro2d/citro3d.

Two teams (Orange / Blue), four characters total, paint a procedurally
generated snowy island. Whoever covers the most ground when the timer hits
zero wins.

---

## What's in this package

```
Makefile          devkitARM build (make = .3dsx, make cia = .cia)
build.sh          one-command helper (./build.sh cia)
basic.rsf         makerom config (UniqueId 0xFF3FF, Application)
icon.png          48x48 CIA icon (title logo)
banner_src.png    256x128 CIA banner image
silence.wav       banner audio (required by bannertool)
include/
  game.h          structs + constants
source/
  main.c          init, sprite loading, game loop, TITLE/PLAYING/OVER states
  map.c           radial island generation + 8px paint grid + scoring
  entity.c        movement, ink trail, heal/damage on floor, respawn, bot AI
  hud.c           top screen (world) + bottom screen (HUD)
gfx/
  tiles.t3s       -> romfs/gfx/tiles.t3x   (water, grass, stone, snow; 16x16)
  chars.t3s       -> romfs/gfx/chars.t3x   (4 skins x [2 idle + 8 walk] = 40)
  hp.t3s          -> romfs/gfx/hp.t3x      (full, empty hearts)
  tiles/  chars/  hp/   <- the source PNGs
```

The `gfx/*.png` were generated from the supplied art pack: the character
animations come from the 4 walk GIFs (8 frames) + 4 idle GIFs (2 frames),
trimmed and scaled to ~28x26 and grouped into 4 skin tones; the tiles are the
four terrain swatches resized to 16x16; the icon/banner use the title logo.

---

## Building

You need **devkitPro** installed (this provides devkitARM, libctru,
citro2d/citro3d, `tex3ds`, and — for the `.cia` — `makerom` and `bannertool`).

```bash
# install once via the devkitPro pacman, then:
export DEVKITPRO=/opt/devkitpro
export DEVKITARM=$DEVKITPRO/devkitARM
export PATH=$DEVKITPRO/tools/bin:$DEVKITARM/bin:$PATH

# .3dsx (Homebrew Launcher):
make

# .cia (install on CFW / Luma3DS):
make cia
# or:
./build.sh cia
```

`make` first runs `tex3ds` on each `gfx/*.t3s` to produce `romfs/gfx/*.t3x`,
then compiles the C and links against citro2d/citro3d/ctru. `make cia` then
builds the banner + SMDH and runs `makerom`.

> Note: this project could not be compiled to a binary in the environment it
> was authored in, because the devkitPro package servers were not reachable
> there. The C compiles warning-free under a strict `-Wall -Wextra` syntax
> check; build it on any machine with devkitPro installed.

---

## How it plays

- **Top screen (400x240):** the island, drawn at `ZOOM 2.0` with a camera that
  follows the player and is clamped to the map edges. Characters are drawn at
  native size (they do not scale with the zoom). The ink layer is
  semitransparent (orange `255,122,24` / blue `43,140,255`, alpha 140).
- **Bottom screen (320x240):** 5 hearts, a big `mm:ss` timer, the
  `LARANJA % x AZUL %` score, and a control hint.
- **States:** TITLE -> (START) -> PLAYING -> (timer hits 0) -> OVER -> (START) -> restart.

### Map
25x16 tiles of 16px. The island is a radial shape with sinusoidal border noise
(different every match). Center becomes a stone cross, the upper third is snow,
the rest grass; outside the border is water. Ink uses a finer 50x30 grid of 8px
cells, on land only (water never paints). Coverage % is over land cells.

### Entities
- 0 = player (Orange, skin 0), 1 = ally bot (Orange, skin 1),
  2 & 3 = enemy bots (Blue, skins 2 & 3).
- Move at 58 px/s; **half speed on enemy ink**; can't walk on water.
- Walking lays an ink trail of your own color (radius ~10px).
- On your own ink: **heal +0.4 HP/s**. On enemy ink: **damage -0.5 HP/s**.
- HP 0 -> dead for 3s -> respawn at base with 1.2s invulnerability (blink).
- `entity_damage()` exists for direct damage (currently floor-ink only).

### Bot AI
Looks for an enemy within ~140px; chases but keeps distance (backs off under
70px). With no enemy near, wanders to random land points, retargeting every
~1.2-2.8s or on arrival.

### Controls
- **Circle Pad:** move the player (Y inverted vs. screen; deadzone ~0.18).
  The character paints automatically while walking (no C-stick needed — Old 3DS
  has none). D-Pad also works.
- **START:** start / play again.
- **START + SELECT:** quit to Homebrew menu.

---

## Atualização: tela de personalização + cabelos e roupas

- Novo estado **ST_CUSTOM** (TÍTULO → START → PERSONALIZAÇÃO → START → JOGO).
- O jogador (P0) escolhe **pele (4), cabelo (6) e roupa (5)** antes da partida.
  Os bots recebem cabelo/roupa sorteados sem repetição.
- Cada personagem é desenhado em **3 camadas** (corpo + roupa + cabelo) pela
  função `draw_character()`, em `hud.c`. As três camadas compartilham o mesmo
  recorte (28×26) e o mesmo centro (0.5, 0.9), então ficam sempre alinhadas —
  tanto no preview quanto no jogo.
- Preview **centralizado** na tela de cima (ampliado 3×, sobre um aro do time);
  menu e controles na tela de baixo.

### Controles da tela de personalização
- **Cima/Baixo** (ou **L/R**): trocar a categoria em foco (pele/cabelo/roupa).
- **Esquerda/Direita**: trocar a opção da categoria.
- **START**: confirmar e começar a partida.

### Novos assets
- `gfx/hair/` (6 cabelos × 10 frames) → `gfx/hair.t3s` → `romfs/gfx/hair.t3x`
- `gfx/cloth/` (5 roupas × 10 frames) → `gfx/cloth.t3s` → `romfs/gfx/cloth.t3x`

### Correção de cores
Todos os `.t3s` agora usam **`-f rgba8`** (em vez de `-f rgba`), o que elimina a
ambiguidade de formato que pode ter causado as cores trocadas/lavadas
(lilás/rosa no lugar de água/grama/pedra) em algumas versões do tex3ds.

---

## Atualização: combate e visual mais orgânico

### Tiro de tinta (L ou R)
- Dispara uma gota de tinta na **direção mirada** (a última direção apontada
  no D-Pad/circle pad). Para atirar parado, segure a direção e aperte L/R.
- A gota **pinta o chão** por onde passa e ao cair, e **causa dano** em inimigo
  que acertar (`SHOT_DMG`). Tem cadência (`SHOOT_CD`) e alcance limitado pela
  vida do projétil (`SHOT_LIFE`).
- Os **bots também atiram** quando têm um alvo em alcance.

### Ataque corpo-a-corpo (A)
- Golpe curto que dá dano (`MELEE_DMG`) em qualquer inimigo dentro de
  `MELEE_RANGE`. Útil de pertinho.

### Visual menos quadrado
- A **costa da ilha** é suavizada: nas quinas terra/água é desenhado um arco de
  água que quebra o serrilhado de 16px.
- A **tinta** agora é desenhada como gotas circulares sobrepostas (raio maior
  que a célula), em vez de blocos de 8px — contorno bem mais orgânico.
- Os projéteis aparecem como gotinhas da cor do time.

### Constantes ajustáveis (em include/game.h)
`SHOT_SPEED, SHOT_LIFE, SHOT_RADIUS, SHOT_DMG, SHOOT_CD, MELEE_CD,
MELEE_RANGE, MELEE_DMG, MAX_SHOTS`.

### Resumo dos controles em jogo
- **D-Pad / Circle Pad**: mover e mirar.
- **L / R**: atirar tinta.
- **A**: ataque corpo-a-corpo.
- **START**: (no fim) voltar à personalização.
- **START + SELECT**: sair.

---

## Atualização: combate, inimigo neutro e visual mais orgânico

### Controles novos (em jogo)
- **L ou R**: atirar tinta. **Mire com o D-Pad** enquanto segura L/R — o tiro
  sai na direção apontada. O projétil pinta o chão por onde passa/cai **e dá
  dano** a inimigos que acertar.
- **A**: ataque corpo-a-corpo curto — dá dano a NPCs próximos à sua frente.
- Sem atirar, o D-Pad também move (além do Circle Pad).

### Dente alado (新: inimigo neutro)
Uma criatura — um **dente com asas** (combina com o tema "anjo") — **surge do
nada** a cada 6–12s numa borda do mapa, voa perseguindo o jogador vivo mais
próximo e **causa dano a qualquer personagem** que encostar (não tem time:
ataca todos). Some após ~12s. Sprite animado de 4 frames (asas batendo), em
`gfx/foe/` → `gfx/foe.t3s` → `romfs/gfx/foe.t3x`.

### Menos "quadrado"
- A **tinta** é desenhada como círculos sobrepostos (raio 0.95 da célula), não
  blocos — fica orgânica.
- As **bordas da ilha** têm os cantos costeiros arredondados (círculos da cor
  da água sobre os cantos de terra cercados por água), quebrando o serrilhado
  de 16px.
