Versao corrigida:
- Audio desativado para evitar crash no Old 3DS.
- C2D_DrawEllipse removido para compatibilidade com citro2d atual.
- .t3s recriados sem border/padding invalidos.
- Makefile CIA agora tenta incluir RomFS para evitar crash por assets ausentes.

No Codespace/Mac com Docker:
cd proj
bash build_codespace.sh
