#ifndef GAME_H
#define GAME_H

#include <citro2d.h>
#include <citro3d.h>
#include <3ds.h>
#include <stdbool.h>

/* ===== Screen dimensions ===== */
#define TOP_W    400
#define TOP_H    240
#define BOT_W    320
#define BOT_H    240

/* ===== World / map ===== */
#define TILE      16
#define MAP_W     25            /* 25 * 16 = 400 */
#define MAP_H     16            /* 16 * 16 = 240 */
#define ZOOM      2.0f          /* world is drawn 2x on the top screen */

/* paint grid (finer, 8px cells over land only) */
#define PAINT     8
#define PAINT_W   50            /* 400 / 8 */
#define PAINT_H   30            /* 240 / 8 */

/* tile kinds */
enum { T_WATER = 0, T_GRASS, T_STONE, T_SNOW, T_COUNT };

/* paint cell owner */
enum { P_NONE = 0, P_ORANGE, P_BLUE };

/* ===== Teams ===== */
enum { TEAM_ORANGE = 0, TEAM_BLUE = 1 };

/* ===== Entities ===== */
#define MAX_ENT      4
#define ENT_MAX_HP   5.0f
#define ENT_SPEED    58.0f       /* px / s */
#define PAINT_RADIUS 10.0f
#define DEAD_TIME    3.0f
#define INVULN_TIME  1.2f

#define IDLE_FRAMES  2
#define WALK_FRAMES  8

#define NUM_HAIR     6
#define NUM_CLOTHES  5
#define NUM_ACC      6   /* acessorios; alem disso o indice 0 = nenhum */

/* ===== Tiro de tinta (L/R) ===== */
#define MAX_SHOTS    24
#define SHOT_SPEED   150.0f      /* px/s */
#define SHOT_LIFE    1.1f        /* segundos de voo */
#define SHOT_RADIUS  9.0f        /* raio de pintura ao viajar/cair */
#define SHOT_DMG     1.0f        /* dano ao acertar inimigo */
#define SHOOT_CD     0.18f       /* cadencia entre tiros */

/* ===== Ataque corpo-a-corpo (A) ===== */
#define MELEE_RANGE  22.0f
#define MELEE_DMG    1.5f
#define MELEE_CD     0.45f

/* ===== Dente alado (inimigo neutro) ===== */
#define TOOTH_FRAMES   4
#define TOOTH_SPEED    34.0f
#define TOOTH_DMG      0.9f      /* dano por toque (aplicado por segundo) */
#define TOOTH_TOUCH    13.0f     /* raio de toque */
#define TOOTH_LIFE     12.0f     /* vive 12s e some */
#define TOOTH_SPAWN_MIN 6.0f     /* surge a cada 6..12s */
#define TOOTH_SPAWN_MAX 12.0f

/* ===== Logo animada (titulo / fim) ===== */
#define LOGO_FRAMES  13

typedef struct {
    float x, y;          /* world position (pixels) */
    int   team;          /* TEAM_ORANGE / TEAM_BLUE */
    int   skin;          /* 0..3 */
    int   hair;          /* 0..NUM_HAIR-1 */
    int   cloth;         /* 0..NUM_CLOTHES-1 */
    int   acc;           /* 0 = nenhum; 1..NUM_ACC = acessorio */
    float hp;
    bool  alive;
    float deadTimer;     /* counts down while dead */
    float invuln;        /* invulnerability timer after respawn */

    /* animation */
    bool  walking;
    float animTime;
    int   frame;
    int   facing;        /* -1 left, +1 right */
    float aimX, aimY;    /* ultima direcao apontada (normalizada) */
    float shootCd;       /* cooldown do tiro de tinta */
    float meleeCd;       /* cooldown do ataque corpo-a-corpo (A) */

    /* AI */
    float aiTimer;
    float tx, ty;        /* wander / chase target */
} Entity;

/* ===== Projeteis de tinta ===== */
typedef struct {
    bool  active;
    float x, y;
    float vx, vy;
    float life;
    int   team;          /* time dono (define a cor) */
} Shot;

/* ===== Game state ===== */
enum { ST_TITLE = 0, ST_CUSTOM, ST_PLAYING, ST_OVER };

#define MATCH_TIME 120.0f   /* 2 minutes */

typedef struct {
    int    state;
    float  timeLeft;
    int    spawnTeam[MAX_ENT];

    /* map */
    unsigned char tiles[MAP_H][MAP_W];
    unsigned char paint[PAINT_H][PAINT_W];   /* P_NONE/P_ORANGE/P_BLUE */

    /* base spawn points (world px) */
    float baseX[2], baseY[2];

    Entity ent[MAX_ENT];
    Shot   shots[MAX_SHOTS];

    /* dente alado: inimigo neutro que surge sozinho */
    struct {
        bool  active;
        float x, y, vx, vy;
        float life;
        float animTime;
        int   frame;
    } tooth;
    float toothSpawnTimer;

    /* cached score */
    int pctOrange, pctBlue;

    /* escolha do jogador na tela de personalizacao */
    int selSkin, selHair, selCloth;
    int selAcc;   /* 0 = nenhum; 1..NUM_ACC */
    int selCat;   /* categoria em foco: 0=skin 1=cabelo 2=roupa 3=acessorio */
} Game;

/* ===== Sprite assets ===== */
typedef struct {
    C2D_Sprite idle[IDLE_FRAMES];
    C2D_Sprite walk[WALK_FRAMES];
} CharSprites;

typedef struct {
    C2D_SpriteSheet sheetTiles;
    C2D_SpriteSheet sheetChars;
    C2D_SpriteSheet sheetHair;
    C2D_SpriteSheet sheetCloth;
    C2D_SpriteSheet sheetAcc;
    C2D_SpriteSheet sheetHp;
    C2D_SpriteSheet sheetFoe;
    C2D_SpriteSheet sheetLogo;

    C2D_Image tile[T_COUNT];
    CharSprites chr[4];
    CharSprites hair[NUM_HAIR];
    CharSprites cloth[NUM_CLOTHES];
    CharSprites acc[NUM_ACC];
    C2D_Image hpFull, hpEmpty;
    C2D_Sprite tooth[TOOTH_FRAMES];
    C2D_Sprite logo[LOGO_FRAMES];
} Assets;

/* ===== map.c ===== */
void map_generate(Game *g);
bool map_is_land_px(const Game *g, float px, float py);
int  map_tile_at_px(const Game *g, float px, float py);
void map_paint_at(Game *g, float px, float py, int owner, float radius);
int  map_paint_owner_px(const Game *g, float px, float py);
void map_compute_score(Game *g);

/* ===== entity.c ===== */
void entity_init_all(Game *g);
void entity_spawn(Game *g, int i);
void entity_update(Game *g, int i, float dt, u32 kHeld, circlePosition cp);
void entity_damage(Game *g, int i, float amount);
void shots_update(Game *g, float dt);
void entity_shoot(Game *g, int i);
void entity_melee(Game *g, int i);
void tooth_update(Game *g, float dt);

/* ===== hud.c ===== */
void draw_polkadot_bg(float w, float h);
void draw_top(Game *g, Assets *a, C3D_RenderTarget *top);
void draw_bottom(Game *g, Assets *a, C3D_RenderTarget *bot);

/* desenha um personagem composto (corpo+roupa+cabelo) centrado em (x,y).
   scale aplica zoom uniforme; facing -1 espelha. usado no jogo e no preview. */
void draw_character(Assets *a, int skin, int hair, int cloth, int acc,
                    bool walking, int frame, int facing,
                    float x, float y, float scale);

/* ===== audio.c ===== */
void bgm_start(const char *path);
void bgm_stop(void);

/* ===== custom.c ===== */
void draw_custom(Game *g, Assets *a, C3D_RenderTarget *top, C3D_RenderTarget *bot);
void custom_input(Game *g, u32 kDown);

#endif /* GAME_H */
