# 白鳥の天使 — Hakuchou no Tenshi (Dollette Edition)

A 2-minute Splatoon-style **ink war** for the **Nintendo 3DS** (works on Old 3DS),
written in C with devkitARM + libctru + citro2d/citro3d.

---

## Dollette Edition Changes

### Visual Aesthetic
- **Dollette / Polka-Dot theme** throughout: soft pink backgrounds, lavender polka
  dots on every screen, cream ribbon stripes, pixel-art bow decorations in corners.
- **Deep rose/maroon HUD** on the bottom screen with matching pink polka dots.
- Team colors updated to **coral-orange** and **periwinkle-blue** to fit the palette.

### Pixel Art (Less Round)
- **Ink is now drawn as full pixel squares** (rectangles) instead of overlapping
  circles — pure pixel-art look, no blending at cell edges.
- **Island coastline** now uses sharp 2px pixel-border strips instead of round arcs.
- **Projectiles** are square pixel blocks instead of circles.
- **Team ring** under characters is a rectangle, not an ellipse.
- **Shadow** under the winged tooth is a rectangle.

### Characters 4x Bigger
- `draw_character()` is called with **scale 4.0** (was 1.0).
- **ZOOM reduced from 2.0 to 1.5** so the full character body (112px tall at 4x)
  is visible on screen without clipping.
- Characters now appear about **4× larger** than before in absolute screen pixels.

### Bigger Map
- **Map expanded from 25×16 to 50×32 tiles** (800×512 world pixels vs 400×256).
- Paint grid expanded from 50×30 to **100×64 cells**.
- Entity speed increased from 58 to **80 px/s** to suit the larger world.
- Tooth enemy speed increased from 34 to **50 px/s**.

### HP Sprites
- The **provided HP.gif / Black_Hp.gif** sprites are used for the heart display
  (converted to 64×64 PNGs and packed into `romfs/gfx/hp.t3x`).

### Minecraftia Font
- **Minecraftia-Regular.ttf** is loaded from `romfs:/font.bcfnt` (you must convert
  the TTF to BCFNT with `mkbcfnt` from devkitPro tools — see Building below).
- All HUD text, timer, scores, menus use Minecraftia when available; falls back to
  the built-in system font if the bcfnt is absent.

---

## Building

```bash
export DEVKITPRO=/opt/devkitpro
export DEVKITARM=$DEVKITPRO/devkitARM
export PATH=$DEVKITPRO/tools/bin:$DEVKITARM/bin:$PATH

# Convert Minecraftia TTF → BCFNT (one-time step):
mkbcfnt romfs/font.ttf -o romfs/font.bcfnt

# Build .3dsx:
make

# Build .cia:
make cia
```

---

## Controls

- **Circle Pad / D-Pad**: move
- **L / R**: shoot ink
- **A**: melee attack
- **START**: start / restart
- **START + SELECT**: quit
