#ifndef GAME_H
#define GAME_H

#include <citro2d.h>
#include <citro3d.h>
#include <3ds.h>
#include <stdbool.h>

/* ===== Screen dimensions ===== */
#define TOP_W    400
#define TOP_H    240
#define BOT_W    320
#define BOT_H    240

/* ===== World / map ===== */
/* Bigger map: 50x32 tiles of 16px = 800x512 world */
#define TILE      16
#define MAP_W     50            /* 50 tiles wide */
#define MAP_H     32            /* 32 tiles tall */
/* Less zoom so the full character body is visible.
   At ZOOM 1.5 the viewport covers 267x160 world-px.
   A 4x-scaled character sprite (28*4=112 px tall) fits on screen. */
#define ZOOM      1.5f

/* paint grid (8px cells over land only) */
#define PAINT     8
#define PAINT_W   100           /* MAP_W * TILE / PAINT = 800/8 */
#define PAINT_H   64            /* MAP_H * TILE / PAINT = 512/8 */

/* tile kinds */
enum { T_WATER = 0, T_GRASS, T_STONE, T_SNOW, T_COUNT };

/* paint cell owner */
enum { P_NONE = 0, P_ORANGE, P_BLUE };

/* ===== Teams ===== */
enum { TEAM_ORANGE = 0, TEAM_BLUE = 1 };

/* ===== Entities ===== */
#define MAX_ENT      4
#define ENT_MAX_HP   5.0f
#define ENT_SPEED    80.0f       /* px / s (faster on bigger map) */
#define PAINT_RADIUS 12.0f
#define DEAD_TIME    3.0f
#define INVULN_TIME  1.2f

#define IDLE_FRAMES  2
#define WALK_FRAMES  8

#define NUM_HAIR     6
#define NUM_CLOTHES  5

/* ===== Tiro de tinta (L/R) ===== */
#define MAX_SHOTS    24
#define SHOT_SPEED   180.0f      /* px/s */
#define SHOT_LIFE    1.3f
#define SHOT_RADIUS  10.0f
#define SHOT_DMG     1.0f
#define SHOOT_CD     0.18f

/* ===== Ataque corpo-a-corpo (A) ===== */
#define MELEE_RANGE  22.0f
#define MELEE_DMG    1.5f
#define MELEE_CD     0.45f

/* ===== Dente alado (inimigo neutro) ===== */
#define TOOTH_FRAMES   4
#define TOOTH_SPEED    50.0f
#define TOOTH_DMG      0.9f
#define TOOTH_TOUCH    13.0f
#define TOOTH_LIFE     14.0f
#define TOOTH_SPAWN_MIN 7.0f
#define TOOTH_SPAWN_MAX 14.0f

/* ===== Dollette / polka dot palette ===== */
/* Background dolls: soft pink/cream */
#define DOLL_BG_R  255
#define DOLL_BG_G  230
#define DOLL_BG_B  240
/* Polka dot color: light lavender */
#define DOT_R  220
#define DOT_G  190
#define DOT_B  230
/* HUD bg: deep rose */
#define HUD_BG_R  60
#define HUD_BG_G  20
#define HUD_BG_B  45

typedef struct {
    float x, y;
    int   team;
    int   skin;
    int   hair;
    int   cloth;
    float hp;
    bool  alive;
    float deadTimer;
    float invuln;

    bool  walking;
    float animTime;
    int   frame;
    int   facing;
    float aimX, aimY;
    float shootCd;
    float meleeCd;

    float aiTimer;
    float tx, ty;
} Entity;

typedef struct {
    bool  active;
    float x, y;
    float vx, vy;
    float life;
    int   team;
} Shot;

enum { ST_TITLE = 0, ST_CUSTOM, ST_PLAYING, ST_OVER };

#define MATCH_TIME 120.0f

typedef struct {
    int    state;
    float  timeLeft;
    int    spawnTeam[MAX_ENT];

    unsigned char tiles[MAP_H][MAP_W];
    unsigned char paint[PAINT_H][PAINT_W];

    float baseX[2], baseY[2];

    Entity ent[MAX_ENT];
    Shot   shots[MAX_SHOTS];

    struct {
        bool  active;
        float x, y, vx, vy;
        float life;
        float animTime;
        int   frame;
    } tooth;
    float toothSpawnTimer;

    int pctOrange, pctBlue;

    int selSkin, selHair, selCloth;
    int selCat;
} Game;

typedef struct {
    C2D_Sprite idle[IDLE_FRAMES];
    C2D_Sprite walk[WALK_FRAMES];
} CharSprites;

typedef struct {
    C2D_SpriteSheet sheetTiles;
    C2D_SpriteSheet sheetChars;
    C2D_SpriteSheet sheetHair;
    C2D_SpriteSheet sheetCloth;
    C2D_SpriteSheet sheetHp;
    C2D_SpriteSheet sheetFoe;

    C2D_Image tile[T_COUNT];
    CharSprites chr[4];
    CharSprites hair[NUM_HAIR];
    CharSprites cloth[NUM_CLOTHES];
    C2D_Image hpFull, hpEmpty;
    C2D_Sprite tooth[TOOTH_FRAMES];

    /* Minecraftia font loaded from romfs */
    C2D_Font font;
} Assets;

/* ===== map.c ===== */
void map_generate(Game *g);
bool map_is_land_px(const Game *g, float px, float py);
int  map_tile_at_px(const Game *g, float px, float py);
void map_paint_at(Game *g, float px, float py, int owner, float radius);
int  map_paint_owner_px(const Game *g, float px, float py);
void map_compute_score(Game *g);

/* ===== entity.c ===== */
void entity_init_all(Game *g);
void entity_spawn(Game *g, int i);
void entity_update(Game *g, int i, float dt, u32 kHeld, circlePosition cp);
void entity_damage(Game *g, int i, float amount);
void shots_update(Game *g, float dt);
void entity_shoot(Game *g, int i);
void entity_melee(Game *g, int i);
void tooth_update(Game *g, float dt);

/* ===== hud.c ===== */
void draw_top(Game *g, Assets *a, C3D_RenderTarget *top);
void draw_bottom(Game *g, Assets *a, C3D_RenderTarget *bot);

void draw_character(Assets *a, int skin, int hair, int cloth,
                    bool walking, int frame, int facing,
                    float x, float y, float scale);

/* ===== custom.c ===== */
void draw_custom(Game *g, Assets *a, C3D_RenderTarget *top, C3D_RenderTarget *bot);
void custom_input(Game *g, u32 kDown);

#endif /* GAME_H */
