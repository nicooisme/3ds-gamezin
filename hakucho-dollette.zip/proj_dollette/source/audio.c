#include "game.h"
#include <ndsp/ndsp.h>
#include <ndsp/ndsp-component.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* WAV header struct */
typedef struct {
    char     riff[4];
    uint32_t fileSize;
    char     wave[4];
    char     fmt[4];
    uint32_t fmtSize;
    uint16_t audioFmt;
    uint16_t numChan;
    uint32_t sampleRate;
    uint32_t byteRate;
    uint16_t blockAlign;
    uint16_t bitsPerSample;
    char     data[4];
    uint32_t dataSize;
} WavHeader;

static ndspWaveBuf wavBuf[2];
static uint8_t    *audioBuf = NULL;
static bool        ndspReady = false;

void audio_init(void)
{
    if (ndspInit() != 0) return;
    ndspReady = true;

    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    ndspChnReset(0);
    ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
    ndspChnSetRate(0, 32728.0f);
    ndspChnSetFormat(0, NDSP_FORMAT_STEREO_PCM16);

    float mix[12] = {0};
    mix[0] = mix[1] = 1.0f;   /* L→L, R→R */
    ndspChnSetMix(0, mix);
}

bool audio_play_bgm(const char *path)
{
    if (!ndspReady) return false;

    FILE *f = fopen(path, "rb");
    if (!f) return false;

    WavHeader hdr;
    if (fread(&hdr, sizeof hdr, 1, f) != 1) { fclose(f); return false; }

    size_t dataSize = hdr.dataSize;
    audioBuf = (uint8_t *)linearAlloc(dataSize);
    if (!audioBuf) { fclose(f); return false; }

    fread(audioBuf, 1, dataSize, f);
    fclose(f);

    DSP_FlushDataCache(audioBuf, dataSize);

    memset(wavBuf, 0, sizeof wavBuf);
    wavBuf[0].data_vaddr  = audioBuf;
    wavBuf[0].nsamples    = dataSize / (hdr.numChan * (hdr.bitsPerSample / 8));
    wavBuf[0].looping     = true;   /* loop infinito! */
    wavBuf[0].status      = NDSP_WBUF_FREE;

    ndspChnWaveBufAdd(0, &wavBuf[0]);
    return true;
}

void audio_set_volume(float vol)
{
    if (!ndspReady) return;
    float mix[12] = {0};
    mix[0] = mix[1] = vol;
    ndspChnSetMix(0, mix);
}

void audio_exit(void)
{
    if (!ndspReady) return;
    ndspChnReset(0);
    if (audioBuf) { linearFree(audioBuf); audioBuf = NULL; }
    ndspExit();
}
