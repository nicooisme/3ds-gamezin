#include "game.h"
#include <stdio.h>
#include <math.h>

/* ===== Dollette / Polka-Dot color palette ===== */
/* Team ink: warm coral-orange vs periwinkle-blue — keeps pastel dollette feel */
#define ORANGE_R 255
#define ORANGE_G 100
#define ORANGE_B  80
#define BLUE_R    90
#define BLUE_G   120
#define BLUE_B   230
#define INK_A    160

/* Polka dot background dot color */
#define DOTCOL C2D_Color32(220, 185, 210, 80)
/* HUD background: deep rose/maroon */
#define HUDCOL C2D_Color32(60, 20, 45, 255)
/* Accent: cream white */
#define CREAM  C2D_Color32(255, 245, 235, 255)

/* ---- helper: draw text with Minecraftia font ---- */
static void draw_text_mc(Assets *a, C2D_TextBuf tb, const char *s,
                         float x, float y, float sz, u32 col)
{
    C2D_Text t;
    if (a->font) {
        C2D_TextFontParse(&t, a->font, tb, s);
    } else {
        C2D_TextParse(&t, tb, s);
    }
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, 0.5f, sz, sz, col);
}

/* ---- pixel-art square ink cell ---- */
static void draw_ink_square(float sx, float sy, float size, u32 col)
{
    /* pure rectangle — no rounding, full pixel art look */
    C2D_DrawRectSolid(sx - size * 0.5f, sy - size * 0.5f,
                      0.01f, size, size, col);
}

/* ---- polka dot background (tiled dots over the screen) ---- */
static void draw_polka_bg(float screenW, float screenH, u32 bgCol, u32 dotCol,
                          float dotR, float spacing)
{
    C2D_DrawRectSolid(0, 0, 0.0f, screenW, screenH, bgCol);
    for (float dy = dotR; dy < screenH + dotR; dy += spacing) {
        for (float dx = dotR; dx < screenW + dotR; dx += spacing) {
            C2D_DrawCircleSolid(dx, dy, 0.02f, dotR, dotCol);
        }
    }
}

/* ---- camera follows player, clamped to map ---- */
static void camera_for(Game *g, float *camX, float *camY)
{
    float px = g->ent[0].x, py = g->ent[0].y;
    float viewW = TOP_W / ZOOM;
    float viewH = TOP_H / ZOOM;
    float cx = px - viewW * 0.5f;
    float cy = py - viewH * 0.5f;
    float maxX = MAP_W * TILE - viewW;
    float maxY = MAP_H * TILE - viewH;
    if (cx < 0) cx = 0;
    if (cx > maxX) cx = maxX;
    if (cy < 0) cy = 0;
    if (cy > maxY) cy = maxY;
    *camX = cx; *camY = cy;
}

void draw_top(Game *g, Assets *a, C3D_RenderTarget *top)
{
    C2D_SceneBegin(top);

    /* dollette polka-dot background */
    draw_polka_bg(TOP_W, TOP_H,
                  C2D_Color32(255, 220, 235, 255),   /* soft pink bg */
                  C2D_Color32(220, 175, 205, 100),   /* lavender dots */
                  6.0f, 22.0f);

    float camX, camY;
    camera_for(g, &camX, &camY);

    /* visible tile range */
    int tx0 = (int)(camX / TILE);
    int ty0 = (int)(camY / TILE);
    int tx1 = tx0 + (int)(TOP_W / (TILE * ZOOM)) + 2;
    int ty1 = ty0 + (int)(TOP_H / (TILE * ZOOM)) + 2;
    if (tx0 < 0) tx0 = 0;
    if (ty0 < 0) ty0 = 0;
    if (tx1 > MAP_W) tx1 = MAP_W;
    if (ty1 > MAP_H) ty1 = MAP_H;

    /* terrain — drawn pixel-perfect (no sub-pixel smoothing) */
    for (int ty = ty0; ty < ty1; ty++) {
        for (int tx = tx0; tx < tx1; tx++) {
            int kind = g->tiles[ty][tx];
            float sx = (tx * TILE - camX) * ZOOM;
            float sy = (ty * TILE - camY) * ZOOM;
            C2D_DrawImageAt(a->tile[kind], sx, sy, 0.0f, NULL, ZOOM, ZOOM);
        }
    }

    /* PIXEL-ART WATER BORDER: sharp 2px pixel lines instead of round arcs */
    {
        u32 waterEdge = C2D_Color32(80, 160, 210, 180);
        float tw = TILE * ZOOM;
        for (int ty = ty0; ty < ty1; ty++) {
            for (int tx = tx0; tx < tx1; tx++) {
                if (g->tiles[ty][tx] == T_WATER) continue;
                float bx = (tx * TILE - camX) * ZOOM;
                float by = (ty * TILE - camY) * ZOOM;
                bool wl = (tx > 0)       && g->tiles[ty][tx-1] == T_WATER;
                bool wr = (tx < MAP_W-1) && g->tiles[ty][tx+1] == T_WATER;
                bool wu = (ty > 0)       && g->tiles[ty-1][tx] == T_WATER;
                bool wd = (ty < MAP_H-1) && g->tiles[ty+1][tx] == T_WATER;
                /* hard pixel border strip (2px wide) on each water-adjacent side */
                float pw = 2.0f;
                if (wl) C2D_DrawRectSolid(bx,          by, 0.04f, pw,  tw, waterEdge);
                if (wr) C2D_DrawRectSolid(bx + tw - pw, by, 0.04f, pw,  tw, waterEdge);
                if (wu) C2D_DrawRectSolid(bx, by,          0.04f, tw, pw, waterEdge);
                if (wd) C2D_DrawRectSolid(bx, by + tw - pw,0.04f, tw, pw, waterEdge);
            }
        }
    }

    /* INK LAYER — pixel-art squares instead of circles */
    int px0 = (int)(camX / PAINT), py0 = (int)(camY / PAINT);
    int px1 = px0 + (int)(TOP_W / (PAINT * ZOOM)) + 2;
    int py1 = py0 + (int)(TOP_H / (PAINT * ZOOM)) + 2;
    if (px0 < 0) px0 = 0;
    if (py0 < 0) py0 = 0;
    if (px1 > PAINT_W) px1 = PAINT_W;
    if (py1 > PAINT_H) py1 = PAINT_H;

    for (int y = py0; y < py1; y++) {
        for (int x = px0; x < px1; x++) {
            int owner = g->paint[y][x];
            if (owner == P_NONE) continue;
            u32 col = (owner == P_ORANGE)
                ? C2D_Color32(ORANGE_R, ORANGE_G, ORANGE_B, INK_A)
                : C2D_Color32(BLUE_R, BLUE_G, BLUE_B, INK_A);
            /* full pixel square — pure pixel art */
            float sx = (x * PAINT - camX) * ZOOM;
            float sy = (y * PAINT - camY) * ZOOM;
            float cell = PAINT * ZOOM;
            C2D_DrawRectSolid(sx, sy, 0.03f, cell, cell, col);
        }
    }

    /* entities at 4x scale; ZOOM reduced so full body is visible */
    for (int i = 0; i < MAX_ENT; i++) {
        Entity *e = &g->ent[i];
        if (!e->alive) continue;
        if (e->invuln > 0.0f && ((int)(e->invuln * 12) & 1)) continue;

        float sx = (e->x - camX) * ZOOM;
        float sy = (e->y - camY) * ZOOM;

        /* team ring: pixel-art rectangle instead of ellipse */
        u32 ring = (e->team == TEAM_ORANGE)
            ? C2D_Color32(ORANGE_R, ORANGE_G, ORANGE_B, 200)
            : C2D_Color32(BLUE_R, BLUE_G, BLUE_B, 200);
        C2D_DrawRectSolid(sx - 16, sy + 2, 0.0f, 32, 6, ring);

        /* 4x character scale (was 1.0 at ZOOM 2.0; now 4.0 / ZOOM = 4x world size) */
        draw_character(a, e->skin, e->hair, e->cloth,
                       e->walking, e->frame, e->facing, sx, sy, 4.0f / ZOOM);
    }

    /* projectiles — pixel square dots */
    for (int s = 0; s < MAX_SHOTS; s++) {
        const Shot *sh = &g->shots[s];
        if (!sh->active) continue;
        float px2 = (sh->x - camX) * ZOOM;
        float py2 = (sh->y - camY) * ZOOM;
        u32 col = (sh->team == TEAM_ORANGE)
            ? C2D_Color32(ORANGE_R, ORANGE_G, ORANGE_B, 255)
            : C2D_Color32(BLUE_R, BLUE_G, BLUE_B, 255);
        /* square pixel bullet */
        float bsz = 5.0f * ZOOM;
        C2D_DrawRectSolid(px2 - bsz * 0.5f, py2 - bsz * 0.5f,
                          0.3f, bsz, bsz, col);
    }

    /* winged tooth enemy */
    if (g->tooth.active) {
        float tx2 = (g->tooth.x - camX) * ZOOM;
        float ty2 = (g->tooth.y - camY) * ZOOM;
        /* pixel shadow: small dark square */
        C2D_DrawRectSolid(tx2 - 10, ty2 + 10, 0.0f, 20, 6,
                          C2D_Color32(0, 0, 0, 60));
        C2D_Sprite *spr = &a->tooth[g->tooth.frame % TOOTH_FRAMES];
        C2D_SpriteSetPos(spr, tx2, ty2);
        C2D_SpriteSetDepth(spr, 0.2f);
        C2D_SpriteSetScale(spr, ZOOM, ZOOM);
        C2D_DrawSprite(spr);
    }
}

/* ---- draw a character in 3 layers ---- */
static void draw_layer(C2D_Sprite *spr, float x, float y, float scale,
                       int facing, float depth)
{
    C2D_SpriteSetPos(spr, x, y);
    C2D_SpriteSetDepth(spr, depth);
    C2D_SpriteSetScale(spr, (float)facing * scale, scale);
    C2D_DrawSprite(spr);
}

void draw_character(Assets *a, int skin, int hair, int cloth,
                    bool walking, int frame, int facing,
                    float x, float y, float scale)
{
    int wf = frame % WALK_FRAMES;
    int idf = frame % IDLE_FRAMES;

    C2D_Sprite *body = walking ? &a->chr[skin].walk[wf]    : &a->chr[skin].idle[idf];
    C2D_Sprite *cl   = walking ? &a->cloth[cloth].walk[wf] : &a->cloth[cloth].idle[idf];
    C2D_Sprite *hr   = walking ? &a->hair[hair].walk[wf]   : &a->hair[hair].idle[idf];

    draw_layer(body, x, y, scale, facing, 0.10f);
    draw_layer(cl,   x, y, scale, facing, 0.11f);
    draw_layer(hr,   x, y, scale, facing, 0.12f);
}

/* ---- HP using the provided HP sprites ---- */
static void draw_heart(Assets *a, float x, float y, bool full)
{
    C2D_Image img = full ? a->hpFull : a->hpEmpty;
    /* HP gif sprites: draw at ~44px height to fit in the dollette HUD bar */
    float s = 44.0f / 64.0f;
    C2D_DrawImageAt(img, x, y, 0.5f, NULL, s, s);
}

/* ---- bottom screen: dollette HUD ---- */
void draw_bottom(Game *g, Assets *a, C3D_RenderTarget *bot)
{
    C2D_SceneBegin(bot);

    /* dollette HUD background: deep rose with polka dots */
    draw_polka_bg(BOT_W, BOT_H,
                  C2D_Color32(HUD_BG_R, HUD_BG_G, HUD_BG_B, 255),
                  C2D_Color32(100, 40, 70, 120),
                  5.0f, 20.0f);

    /* decorative ribbon stripe across top */
    C2D_DrawRectSolid(0, 52, 0.01f, BOT_W, 3, C2D_Color32(220, 140, 170, 200));

    /* 5 HP hearts using the provided HP sprites */
    int hp = (int)ceilf(g->ent[0].hp);
    for (int i = 0; i < 5; i++)
        draw_heart(a, 10 + i * 50, 4, i < hp);

    C2D_TextBuf tb = C2D_TextBufNew(256);

    /* timer — Minecraftia font, cream color */
    int total = (int)ceilf(g->timeLeft);
    if (total < 0) total = 0;
    char buf[16];
    snprintf(buf, sizeof buf, "%02d:%02d", total / 60, total % 60);
    float tw, th;
    C2D_Text ttxt;
    if (a->font) C2D_TextFontParse(&ttxt, a->font, tb, buf);
    else         C2D_TextParse(&ttxt, tb, buf);
    C2D_TextOptimize(&ttxt);
    C2D_TextGetDimensions(&ttxt, 1.4f, 1.4f, &tw, &th);
    C2D_DrawText(&ttxt, C2D_WithColor,
                 (BOT_W - tw) / 2, 62, 0.5f, 1.4f, 1.4f,
                 C2D_Color32(255, 240, 200, 255));

    /* score */
    char sc[48];
    snprintf(sc, sizeof sc, "LARANJA %d%%  x  AZUL %d%%", g->pctOrange, g->pctBlue);
    draw_text_mc(a, tb, sc,
                 16, 110, 0.55f,
                 C2D_Color32(255, 200, 220, 255));

    /* control hint */
    const char *hint =
        (g->state == ST_PLAYING) ? "Circle Pad: mover" :
        (g->state == ST_TITLE)   ? "Pressione START" :
                                   "START: jogar de novo";
    draw_text_mc(a, tb, hint,
                 16, 155, 0.50f,
                 C2D_Color32(200, 170, 190, 255));

    C2D_TextBufDelete(tb);
}
