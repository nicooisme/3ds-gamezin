#include "game.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

static Assets A;
static Game   G;

static void load_charsprites(CharSprites *cs, C2D_SpriteSheet sheet, int base)
{
    int idx = base;
    for (int f = 0; f < IDLE_FRAMES; f++) {
        C2D_SpriteFromSheet(&cs->idle[f], sheet, idx++);
        C2D_SpriteSetCenter(&cs->idle[f], 0.5f, 0.9f);
    }
    for (int f = 0; f < WALK_FRAMES; f++) {
        C2D_SpriteFromSheet(&cs->walk[f], sheet, idx++);
        C2D_SpriteSetCenter(&cs->walk[f], 0.5f, 0.9f);
    }
}

static void load_assets(void)
{
    A.sheetTiles = C2D_SpriteSheetLoad("romfs:/gfx/tiles.t3x");
    A.sheetChars = C2D_SpriteSheetLoad("romfs:/gfx/chars.t3x");
    A.sheetHair  = C2D_SpriteSheetLoad("romfs:/gfx/hair.t3x");
    A.sheetCloth = C2D_SpriteSheetLoad("romfs:/gfx/cloth.t3x");
    A.sheetHp    = C2D_SpriteSheetLoad("romfs:/gfx/hp.t3x");
    A.sheetFoe   = C2D_SpriteSheetLoad("romfs:/gfx/foe.t3x");

    for (int i = 0; i < T_COUNT; i++)
        A.tile[i] = C2D_SpriteSheetGetImage(A.sheetTiles, i);

    for (int s = 0; s < 4; s++)
        load_charsprites(&A.chr[s], A.sheetChars, s * 10);
    for (int h = 0; h < NUM_HAIR; h++)
        load_charsprites(&A.hair[h], A.sheetHair, h * 10);
    for (int c = 0; c < NUM_CLOTHES; c++)
        load_charsprites(&A.cloth[c], A.sheetCloth, c * 10);

    A.hpFull  = C2D_SpriteSheetGetImage(A.sheetHp, 0);
    A.hpEmpty = C2D_SpriteSheetGetImage(A.sheetHp, 1);

    for (int f = 0; f < TOOTH_FRAMES; f++) {
        C2D_SpriteFromSheet(&A.tooth[f], A.sheetFoe, f);
        C2D_SpriteSetCenter(&A.tooth[f], 0.5f, 0.5f);
    }

    /* Load Minecraftia pixel-art font from romfs.
       Falls back gracefully to system font if file is absent. */
    A.font = C2D_FontLoad("romfs:/font.bcfnt");
    if (!A.font) {
        /* try alternate extension in case tex3ds output differs */
        A.font = C2D_FontLoad("romfs:/Minecraftia.bcfnt");
    }
    /* A.font may be NULL — hud.c falls back to default font in that case */
}

static void start_match(void)
{
    srand((unsigned)svcGetSystemTick());
    map_generate(&G);
    entity_init_all(&G);
    for (int s = 0; s < MAX_SHOTS; s++) G.shots[s].active = false;
    G.tooth.active = false;
    G.toothSpawnTimer = TOOTH_SPAWN_MIN;
    G.timeLeft = MATCH_TIME;
    map_compute_score(&G);
    G.state = ST_PLAYING;
}

static void draw_centered_banner(C3D_RenderTarget *top, Assets *a,
                                 const char *line1, const char *line2)
{
    C2D_SceneBegin(top);
    /* dollette banner bg */
    C2D_TargetClear(top, C2D_Color32(50, 15, 35, 255));
    /* polka dots */
    for (float dy = 14; dy < TOP_H; dy += 24) {
        for (float dx = 14; dx < TOP_W; dx += 24) {
            C2D_DrawCircleSolid(dx, dy, 0.02f, 7.0f,
                                C2D_Color32(100, 50, 75, 100));
        }
    }
    /* cream ribbon */
    C2D_DrawRectSolid(0, 68, 0.01f, TOP_W, 4,
                      C2D_Color32(255, 220, 200, 180));
    C2D_DrawRectSolid(0, 162, 0.01f, TOP_W, 4,
                      C2D_Color32(255, 220, 200, 180));

    C2D_TextBuf tb = C2D_TextBufNew(128);
    C2D_Text t1, t2;
    if (a->font) {
        C2D_TextFontParse(&t1, a->font, tb, line1);
        C2D_TextFontParse(&t2, a->font, tb, line2);
    } else {
        C2D_TextParse(&t1, tb, line1);
        C2D_TextParse(&t2, tb, line2);
    }
    C2D_TextOptimize(&t1);
    C2D_TextOptimize(&t2);
    float w1, h1, w2, h2;
    C2D_TextGetDimensions(&t1, 1.2f, 1.2f, &w1, &h1);
    C2D_TextGetDimensions(&t2, 0.7f, 0.7f, &w2, &h2);
    C2D_DrawText(&t1, C2D_WithColor, (TOP_W - w1) / 2, 80, 0.5f, 1.2f, 1.2f,
                 C2D_Color32(255, 235, 215, 255));
    C2D_DrawText(&t2, C2D_WithColor, (TOP_W - w2) / 2, 140, 0.5f, 0.7f, 0.7f,
                 C2D_Color32(255, 190, 220, 255));
    C2D_TextBufDelete(tb);
}

int main(int argc, char **argv)
{
    (void)argc; (void)argv;

    romfsInit();
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    audio_init();

    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    load_assets();

    audio_play_bgm("romfs:/bgm.wav");
    memset(&G, 0, sizeof G);
    G.state = ST_TITLE;
    srand((unsigned)svcGetSystemTick());
    map_generate(&G);
    entity_init_all(&G);
    map_compute_score(&G);

    u64 lastTick = svcGetSystemTick();
    const float TICKS_PER_SEC = 268123480.0f;

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kHeld = hidKeysHeld();
        circlePosition cp; hidCircleRead(&cp);
        if (kDown & KEY_START) {
            if (G.state == ST_TITLE) {
                G.state = ST_CUSTOM;
            } else if (G.state == ST_CUSTOM) {
                start_match();
            } else if (G.state == ST_OVER) {
                G.state = ST_CUSTOM;
            }
        }
        if ((kHeld & KEY_START) && (kHeld & KEY_SELECT)) break;
        if (G.state == ST_CUSTOM) custom_input(&G, kDown);

        u64 now = svcGetSystemTick();
        float dt = (float)(now - lastTick) / TICKS_PER_SEC;
        lastTick = now;
        if (dt > 0.05f) dt = 0.05f;

        if (G.state == ST_PLAYING) {
            for (int i = 0; i < MAX_ENT; i++)
                entity_update(&G, i, dt, kHeld, cp);
            shots_update(&G, dt);
            tooth_update(&G, dt);
            map_compute_score(&G);
            G.timeLeft -= dt;
            if (G.timeLeft <= 0.0f) { G.timeLeft = 0; G.state = ST_OVER; }
        }

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        if (G.state == ST_TITLE) {
            draw_centered_banner(top, &A, "Hakuchou no Tenshi", "START para comecar");
            draw_bottom(&G, &A, bot);
        } else if (G.state == ST_CUSTOM) {
            draw_custom(&G, &A, top, bot);
        } else if (G.state == ST_OVER) {
            char res[48];
            const char *who = (G.pctOrange > G.pctBlue) ? "LARANJA VENCE!" :
                              (G.pctBlue > G.pctOrange) ? "AZUL VENCE!" : "EMPATE!";
            snprintf(res, sizeof res, "%d%%  x  %d%%", G.pctOrange, G.pctBlue);
            draw_centered_banner(top, &A, who, res);
            draw_bottom(&G, &A, bot);
        } else {
            draw_top(&G, &A, top);
            draw_bottom(&G, &A, bot);
        }

        C3D_FrameEnd(0);
    }

    audio_exit();
    if (A.font) C2D_FontFree(A.font);
    C2D_SpriteSheetFree(A.sheetTiles);
    C2D_SpriteSheetFree(A.sheetChars);
    C2D_SpriteSheetFree(A.sheetHair);
    C2D_SpriteSheetFree(A.sheetCloth);
    C2D_SpriteSheetFree(A.sheetHp);
    C2D_SpriteSheetFree(A.sheetFoe);
    C2D_Fini();
    C3D_Fini();
    gfxExit();
    romfsExit();
    return 0;
}
