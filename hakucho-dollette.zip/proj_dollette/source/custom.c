#include "game.h"
#include <stdio.h>

#define ORANGE_R 255
#define ORANGE_G 100
#define ORANGE_B  80

#define NUM_SKIN 4

static int cat_count(int cat)
{
    switch (cat) {
        case 0: return NUM_SKIN;
        case 1: return NUM_HAIR;
        case 2: return NUM_CLOTHES;
    }
    return 1;
}

static int *cat_value(Game *g, int cat)
{
    switch (cat) {
        case 0: return &g->selSkin;
        case 1: return &g->selHair;
        case 2: return &g->selCloth;
    }
    return &g->selSkin;
}

void custom_input(Game *g, u32 kDown)
{
    if (kDown & KEY_DOWN) g->selCat = (g->selCat + 1) % 3;
    if (kDown & KEY_UP)   g->selCat = (g->selCat + 2) % 3;

    int n = cat_count(g->selCat);
    int *v = cat_value(g, g->selCat);
    if (kDown & KEY_RIGHT) *v = (*v + 1) % n;
    if (kDown & KEY_LEFT)  *v = (*v + n - 1) % n;

    if (kDown & KEY_R) g->selCat = (g->selCat + 1) % 3;
    if (kDown & KEY_L) g->selCat = (g->selCat + 2) % 3;
}

/* helper: draw text, uses Minecraftia font if available */
static void text_mc(Assets *a, C2D_TextBuf buf, const char *s,
                    float x, float y, float sz, u32 col)
{
    C2D_Text t;
    if (a->font)
        C2D_TextFontParse(&t, a->font, buf, s);
    else
        C2D_TextParse(&t, buf, s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, 0.5f, sz, sz, col);
}

void draw_custom(Game *g, Assets *a, C3D_RenderTarget *top, C3D_RenderTarget *bot)
{
    /* === TOP SCREEN: character preview === */
    C2D_SceneBegin(top);

    /* dollette pink polka-dot background */
    C2D_TargetClear(top, C2D_Color32(255, 218, 230, 255));
    for (float dy = 18; dy < TOP_H; dy += 26) {
        for (float dx = 18; dx < TOP_W; dx += 26) {
            C2D_DrawCircleSolid(dx, dy, 0.02f, 8.0f,
                                C2D_Color32(210, 170, 200, 90));
        }
    }

    /* decorative bows (pixel-art rectangles) in corners */
    u32 bowCol = C2D_Color32(230, 100, 140, 200);
    /* top-left bow */
    C2D_DrawRectSolid(4,  4,  0.01f, 20, 8, bowCol);
    C2D_DrawRectSolid(10, 8,  0.01f, 8,  16, bowCol);
    /* top-right bow */
    C2D_DrawRectSolid(TOP_W-24, 4,  0.01f, 20, 8, bowCol);
    C2D_DrawRectSolid(TOP_W-18, 8,  0.01f, 8,  16, bowCol);

    float cx = TOP_W * 0.5f;
    float cy = TOP_H * 0.5f;

    /* team ring — square pixel-art style */
    C2D_DrawRectSolid(cx - 50, cy + 38, 0.0f, 100, 16,
                      C2D_Color32(ORANGE_R, ORANGE_G, ORANGE_B, 100));
    C2D_DrawRectSolid(cx - 48, cy + 40, 0.0f, 96, 12,
                      C2D_Color32(255, 160, 130, 60));

    /* character at 4x scale, placed so feet land on ring */
    float footY = cy + 50.0f;
    draw_character(a, g->selSkin, g->selHair, g->selCloth,
                   false, 0, +1, cx, footY, 4.0f);

    C2D_TextBuf tb = C2D_TextBufNew(64);
    text_mc(a, tb, "Monte seu personagem",
            cx - 100, 10, 0.65f, C2D_Color32(80, 30, 55, 255));
    C2D_TextBufDelete(tb);

    /* === BOTTOM SCREEN: dollette menu === */
    C2D_SceneBegin(bot);

    /* deep rose polka bg */
    C2D_TargetClear(bot, C2D_Color32(60, 20, 45, 255));
    for (float dy = 16; dy < BOT_H; dy += 22) {
        for (float dx = 16; dx < BOT_W; dx += 22) {
            C2D_DrawCircleSolid(dx, dy, 0.02f, 5.5f,
                                C2D_Color32(100, 40, 70, 110));
        }
    }

    /* ribbon stripes */
    C2D_DrawRectSolid(0, 28, 0.01f, BOT_W, 3, C2D_Color32(200, 130, 160, 180));
    C2D_DrawRectSolid(0, BOT_H - 44, 0.01f, BOT_W, 3, C2D_Color32(200, 130, 160, 180));

    C2D_TextBuf b = C2D_TextBufNew(256);
    const char *names[3] = { "Pele", "Cabelo", "Roupa" };
    int vals[3]  = { g->selSkin + 1, g->selHair + 1, g->selCloth + 1 };
    int maxs[3]  = { NUM_SKIN, NUM_HAIR, NUM_CLOTHES };

    for (int i = 0; i < 3; i++) {
        float y = 38 + i * 44;
        bool focus = (g->selCat == i);
        u32 col = focus ? C2D_Color32(255, 220, 200, 255)
                        : C2D_Color32(190, 150, 170, 255);
        if (focus) {
            /* pixel-art highlight box */
            C2D_DrawRectSolid(10, y - 6, 0.0f, BOT_W - 20, 36,
                              C2D_Color32(120, 50, 80, 180));
            C2D_DrawRectSolid(10, y - 6, 0.0f, BOT_W - 20, 2,
                              C2D_Color32(220, 140, 170, 200));
            C2D_DrawRectSolid(10, y + 28, 0.0f, BOT_W - 20, 2,
                              C2D_Color32(220, 140, 170, 200));
        }
        char line[48];
        snprintf(line, sizeof line, "%s  <  %d / %d  >", names[i], vals[i], maxs[i]);
        text_mc(a, b, line, 24, y, 0.68f, col);
    }

    text_mc(a, b, "Cima/Baixo: categoria   Esq/Dir: trocar",
            14, BOT_H - 40, 0.42f, C2D_Color32(170, 120, 145, 255));
    text_mc(a, b, "START: comecar a partida",
            14, BOT_H - 22, 0.48f, C2D_Color32(200, 240, 180, 255));
    C2D_TextBufDelete(b);
}
