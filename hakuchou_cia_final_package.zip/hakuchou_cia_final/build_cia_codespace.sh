#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

# Ferramentas: tenta instalar dentro do container devkitPro e também baixar 3dstool se faltar.
docker run --rm -v "$PWD":/proj -w /proj devkitpro/devkitarm:latest bash -lc '
set -e
export DEVKITPRO=/opt/devkitpro
export DEVKITARM=/opt/devkitpro/devkitARM
export PATH=$PATH:/opt/devkitpro/tools/bin:/opt/devkitpro/devkitARM/bin:/proj/tools
mkdir -p /proj/tools

# tenta instalar pacotes devkitPro se existirem
if command -v dkp-pacman >/dev/null 2>&1; then
  dkp-pacman -Sy --noconfirm 3dstool makerom bannertool || true
fi

# baixa 3dstool caso não exista
if ! command -v 3dstool >/dev/null 2>&1; then
  cd /proj/tools
  curl -L -o 3dstool_linux_x86_64.tar.gz https://github.com/dnasdw/3dstool/releases/download/v1.2.6/3dstool_linux_x86_64.tar.gz
  tar -xzf 3dstool_linux_x86_64.tar.gz
  find . -type f -name 3dstool -exec chmod +x {} \;
  export PATH=$PATH:/proj/tools:/proj/tools/3dstool_linux_x86_64:/proj/tools/linux_x86_64
fi

cd /proj
# Se Makefile conseguir fazer cia, usa ele.
if [ -f Makefile ]; then
  make cia || true
fi

# Fallback manual se makerom existir e cia não foi criada.
if [ ! -f hakuchou.cia ]; then
  if ! command -v makerom >/dev/null 2>&1 && [ -x /proj/tools/makerom ]; then export PATH=$PATH:/proj/tools; fi
  if [ ! -f banner.bnr ] && command -v bannertool >/dev/null 2>&1; then
    bannertool makebanner -i banner_src.png -a silence.wav -o banner.bnr || true
  fi
  if [ ! -f icon.icn ] && command -v bannertool >/dev/null 2>&1; then
    bannertool makesmdh -s "Hakuchou" -l "Hakuchou no Tenshi" -p "Nico" -i icon.png -o icon.icn || true
  fi
  makerom -f cia -o hakuchou.cia -elf hakuchou.elf -rsf basic.rsf ${icon:+} -icon ${icon:-icon.icn} -banner ${banner:-banner.bnr} || \
  makerom -f cia -o hakuchou.cia -elf hakuchou.elf -rsf basic.rsf
fi

ls -lh hakuchou.cia
'
